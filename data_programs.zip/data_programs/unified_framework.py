#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Unified Field Framework — ALL-IN-ONE (formulas U1-U18 + plots + CLI).
pip install numpy scipy matplotlib
python unified_framework.py
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.gridspec import GridSpec
from scipy.integrate import quad, solve_ivp
from scipy.optimize import brentq, fsolve, minimize_scalar
from scipy.special import gamma, gammaincc

@dataclass(frozen=True)
class FrameworkParams:
    """Physical / numerical parameters."""

    gamma: float = 0.05
    m: float = 1.0
    d: float = 4.0
    alpha_bh: float = 0.1
    ell_p: float = 1.0
    k_b: float = 1.0
    b0_qcd: float = 1.0  # one-loop beta coefficient (set 11/(48 pi^2) for SU(3))
    chi_nr: float = 0.05  # nonreciprocal coupling (nrv2-type)
    phi_R_im_amp: float = 0.1  # Im dPhi_R/d ln L amplitude for demo
    # --- refs batch (Kohn/Luttinger/Lloyd/Rashba/moire) ---
    m_band_curv: float = 0.02  # U9 Luttinger-Kohn band curvature correction
    v_F: float = 1.0  # U10 Tomonaga-Luttinger Fermi velocity
    g_tl: float = 0.3  # U10 TL interaction strength
    channel_dim: float = 2.0  # U11 Holevo capacity dimension
    alpha_rashba: float = 0.05  # U13 Rashba spin-orbit (eV·Å^2 scale, reduced units)
    delta_valley: float = 0.1  # U14 valley splitting factor
    moire_amp: float = 0.03  # U15 moiré modulation of Omega
    moire_period: float = 1.0  # moiré period in ln L
    moire_L0: float = 0.1  # moiré reference scale
    lattice_a: float = 1.0  # U16 Wannier mesh lattice constant
    T_entropic: float = 0.01  # U17 entropic-force temperature (default on)
    kappa_diss: float = 0.05  # U18 open-system RG damping (default on)


class FrameworkFormulas:
    """Numerical evaluation of all paper formulas."""

    def __init__(self, params: FrameworkParams | None = None) -> None:
        self.p = params or FrameworkParams()

    @staticmethod
    def Z_L(L: float, eta: float, d: float, phi_R0: float = 0.0) -> float:
        """Eq. (4): normalization factor (modulus)."""
        return (2.0 * np.pi * L**2 / (1.0 + 2.0 * L**2 * eta)) ** (d / 2.0)

    @staticmethod
    def M_squared_v41(L: float, eta: float) -> float:
        """v4.1 Thm 1 Eq. (3.1): M^2 = 1/L^2 + 2*eta."""
        return float(1.0 / L**2 + 2.0 * eta)

    @staticmethod
    def Lambda_eff(L: float, eta: float) -> float:
        """Eq. (3.1): M(L) = sqrt(1/L^2 + 2*eta); equivalent to (1+2L^2*eta)/L^2."""
        return float(np.sqrt(FrameworkFormulas.M_squared_v41(L, eta)))

    @staticmethod
    def K_L_real_modulus(r: float, L: float, eta: float) -> float:
        """Real positive kernel |K_L(r)| ∝ exp(−M² r² / 2), with M² = 1/L² + 2η.

        This is the kernel itself (K>0), not |K|². Fourier transform then gives
        |K̂(k)|² = exp(−k² / M²).
        """
        M2 = FrameworkFormulas.M_squared_v41(L, eta)
        return float(np.exp(-0.5 * M2 * r**2))

    def u_scale_numerical(self, L: float, rel_step: float = 1e-5) -> float:
        """Finite-difference d ln M / d ln L for plot verification."""
        if L <= 0.0:
            raise ValueError("L must be positive.")
        h = rel_step
        Mp = self.solve_M(L * (1.0 + h))
        Mm = self.solve_M(L * (1.0 - h))
        return float((np.log(Mp) - np.log(Mm)) / (2.0 * np.log(1.0 + h)))

    @staticmethod
    def K_hat_modulus(k: float, L: float, eta: float) -> float:
        """|K_hat_L(k)| from Eq. (5), ignoring phase."""
        return np.exp(-L**2 * k**2 / (2.0 * (1.0 + 2.0 * L**2 * eta)))

    @staticmethod
    def K_hat_squared(k: float, M: float) -> float:
        """|K_hat_L(k)|^2 = exp(-k^2 / M^2)."""
        return np.exp(-k**2 / M**2)

    @staticmethod
    def eta_from_mobius(c_re: float, c_im: float, d_re: float, d_im: float) -> float:
        """Eq. (12): eta = 4 Re(c d*) / |d|^2."""
        c = complex(c_re, c_im)
        d = complex(d_re, d_im)
        return 4.0 * (c * d.conjugate()).real / (abs(d) ** 2)

    @staticmethod
    def Phi_I_quadratic(w2: float, eta: float) -> float:
        """Leading convex dissipation phase, Eq. (3)."""
        return 0.5 * eta * w2

    def self_consistent_residual(self, M2: float, L: float) -> float:
        """Eq. (15): F(M^2, L) = 0."""
        p = self.p
        if M2 <= 0.0:
            return np.inf
        return L**2 * M2 - 1.0 - p.gamma * L**2 * np.log(M2 / p.m**2)

    def L_max(self) -> float:
        """Maximum L for which Eq. (15) has a real root (mathematical domain)."""
        p = self.p
        denom = p.gamma * (1.0 - np.log(p.gamma / p.m**2))
        if denom <= 0.0:
            return np.inf
        return float(np.sqrt(1.0 / denom))

    def L_IR(self) -> float:
        """Working-closure reference endpoint L_ref = 1/m_R. Kept as L_IR for callers."""
        return float(1.0 / self.p.m)

    def L_ref(self) -> float:
        """Paper name for the working reference endpoint: 1/m_R."""
        return self.L_IR()

    def L_phys(self, m0: float | None = None) -> float:
        """Primary-law physical IR endpoint: 1/m_0."""
        m0 = float(self.p.m if m0 is None else m0)
        return float(1.0 / m0)

    def eta_nonneg(self, L: float) -> bool:
        """True when closure (14) gives eta >= 0 on the UV branch (M >= m)."""
        if L <= 0.0:
            return False
        try:
            return self.solve_M(L) >= self.p.m - 1e-9
        except (ValueError, RuntimeError):
            return False

    def solve_M(self, L: float) -> float:
        """Solve Eq. (15) for M(L) > 0 on the UV branch."""
        if L <= 0.0:
            raise ValueError("L must be positive.")
        if L > self.L_max() * (1.0 + 1e-9):
            raise ValueError(
                f"No mathematical root for L={L:.6g} > L_max={self.L_max():.6g}. "
                "Reduce L or gamma."
            )
        if L > self.L_IR() * (1.0 + 1e-9):
            import warnings
            warnings.warn(
                f"L={L:.6g} > L_ref={self.L_ref():.6g} (eta>=0 domain): eta<0.",
                stacklevel=2,
            )

        def f(M2: float) -> float:
            if M2 <= 0.0:
                return np.inf
            return self.self_consistent_residual(M2, L)

        guess = max(self.M_small_asymptotic(L), 1e-6)
        M2_guess = max(guess**2, 1e-12)

        for scale in (1e-2, 1e-1, 1.0, 10.0, 100.0, 1e4):
            lo = max(M2_guess / scale, 1e-16)
            hi = M2_guess * scale
            flo, fhi = f(lo), f(hi)
            if flo * fhi <= 0:
                return float(np.sqrt(brentq(f, lo, hi, maxiter=200)))

        grid = np.logspace(-16, 16, 1200)
        vals = np.array([f(M2) for M2 in grid])
        idx = np.where(np.sign(vals[:-1]) * np.sign(vals[1:]) <= 0)[0]
        if len(idx) == 0:
            M2 = fsolve(f, M2_guess, full_output=False)[0]
            if M2 <= 0 or abs(f(M2)) > 1e-6:
                raise RuntimeError(f"No root found for M(L) at L={L}")
            return float(np.sqrt(M2))

        i = idx[-1]
        return float(np.sqrt(brentq(f, grid[i], grid[i + 1], maxiter=200)))

    def eta(self, M: float) -> float:
        """Working-closure soft weight: η = (γ/2) ln(M²/m_R²)."""
        return 0.5 * self.p.gamma * np.log(M**2 / self.p.m**2)

    def ReSigma_sub(self, omega: float, Lambda: float, m0: float | None = None) -> float:
        """Wilson-shell object δM_shell² = (2/π) ∫_{max(|ω|,m0)}^Λ J(ν)/ν² dν = 2γ ln(Λ/max(|ω|,m0)).

        Legacy name ReSigma_sub; this is not the PV remainder of ReΣ.
        """
        m0 = float(self.p.m if m0 is None else m0)
        lo = max(abs(float(omega)), m0)
        Lam = float(Lambda)
        if Lam <= lo:
            return 0.0
        return float(2.0 * self.p.gamma * np.log(Lam / lo))

    def delta_M_shell2(self, omega: float, Lambda: float, m0: float | None = None) -> float:
        """Paper name for the Wilson-shell matching object."""
        return self.ReSigma_sub(omega, Lambda, m0=m0)

    def delta_M_sp2(self, omega: float, Lambda: float, m0: float | None = None) -> float:
        """Ohmic per-e-fold soft weight δM_sp² ≡ δM_shell²."""
        m0 = float(self.p.m if m0 is None else m0)
        return self.ReSigma_sub(max(abs(float(omega)), m0), Lambda, m0=m0)

    def primary_M(self, L: float, m0: float | None = None) -> float:
        """Primary law after matching at ω*=m0: M² = 1/L² + 2γ ln(1/(L m0))."""
        m0 = float(self.p.m if m0 is None else m0)
        if L <= 0.0:
            raise ValueError("L must be positive.")
        arg = 1.0 / (L * m0)
        extra = 0.0 if arg <= 1.0 else 2.0 * self.p.gamma * np.log(arg)
        return float(np.sqrt(1.0 / L**2 + extra))

    def eta_prime(self, L: float, M: float, eta_val: float) -> float:
        """dη/d ln L from implicit differentiation of Eq. (14)+(15)."""
        p = self.p
        denom = M**2 - p.gamma
        if abs(denom) < 1e-14:
            return np.nan
        return p.gamma * (2.0 * eta_val - M**2) / denom

    def Omega(self, L: float, M: float | None = None, eta_val: float | None = None) -> float:
        """Eq. (18): Ω = 1 + (dη/d ln L)/M²; undefined (nan) if M² ≤ γ."""
        if M is None:
            M = self.solve_M(L)
        if eta_val is None:
            eta_val = self.eta(M)
        eta_p = self.eta_prime(L, M, eta_val)
        if not np.isfinite(eta_p):
            return float("nan")
        return 1.0 + eta_p / M**2

    def L_safe(self, omega_min: float = 0.0) -> float:
        """Largest L with Ω(L) ≥ omega_min (physical RG-corrected domain)."""
        L_lo = 1e-6
        L_hi = 0.999 * self.L_max()
        if self.Omega(L_lo) < omega_min:
            return L_lo

        def margin(L: float) -> float:
            return self.Omega(L) - omega_min

        if margin(L_hi) >= 0.0:
            return float(L_hi)
        return float(brentq(margin, L_lo, L_hi))

    def M_small_asymptotic(self, L: float) -> float:
        """UV expansion M = 1/L − γ L ln(L m_R) (paper eq. UV, leading term)."""
        p = self.p
        return 1.0 / L - p.gamma * L * np.log(p.m * L)

    def M_large_asymptotic(self, L: float) -> float:
        """Eq. (17) leading term (requires L ≫ 1; often beyond L_max)."""
        if L <= 1.0:
            return float("nan")
        return float(np.sqrt(self.p.gamma * np.log(L)))

    def I_m(self, L: float, M: float | None = None, eta_val: float | None = None) -> float:
        """Fisher mass information; equals 1/M^2 by Theorem 2."""
        return self.fisher_mass(L, M, eta_val)

    def L_emergent(self, area: float, S_EE: float) -> float:
        """Emergent L from entanglement area law (definition; ell_p input)."""
        if S_EE <= 0.0 or area <= 0.0:
            raise ValueError("area and S_EE must be positive.")
        return float(self.p.ell_p * np.sqrt(area / S_EE))

    def holographic_I_bound(self, area: float, G_N: float = 1.0) -> float:
        """Hypothesis H1: I_m <= Area/(4 G_N) in hbar=1 units."""
        if G_N <= 0.0 or area < 0.0:
            raise ValueError("G_N and area must be positive.")
        return float(area / (4.0 * G_N))

    def eta_flow_rhs(self, L: float, eta_val: float, R: float = 0.0, kappa: float | None = None) -> float:
        """Conjecture C1: L dη/dL = -2η + κ R/L² + O(η²); R=0 is flat limit."""
        kappa = self.p.gamma if kappa is None else kappa
        return float(-2.0 * eta_val + kappa * R / L**2)

    def I_4_leading_relative_error(self, M: float) -> float:
        """Relative error |I4_leading - I4_quad|/|I4_quad| at d=4 (Eq. 20 applicability)."""
        if abs(self.p.d - 4.0) > 1e-12:
            return float("nan")
        exact = self._I_4_quadrature(M, self.p.m)
        approx = self.I_4_leading(M)[2]
        if abs(exact) < 1e-30:
            return float("nan")
        return float(abs(approx - exact) / abs(exact))

    def profile(self, L_values: np.ndarray) -> dict[str, np.ndarray]:
        """Compute M, eta, Omega on an array of L."""
        M = np.array([self.solve_M(L) for L in L_values])
        eta = np.array([self.eta(m) for m in M])
        Omega = np.array([self.Omega(L, m, e) for L, m, e in zip(L_values, M, eta)])
        Lambda = np.array([self.Lambda_eff(L, e) for L, e in zip(L_values, eta)])
        return {"L": L_values, "M": M, "eta": eta, "Omega": Omega, "Lambda_eff": Lambda}

    def I_d(self, M: float, d: float | None = None) -> float:
        """Eq. (19): one-loop integral; uses quadrature at d=4."""
        p = self.p
        d = d if d is not None else p.d
        m, M = p.m, M
        if M <= 0.0:
            raise ValueError("M must be positive.")

        if abs(d - 4.0) < 1e-12:
            return self._I_4_quadrature(M, m)

        alpha = m**2 / M**2
        s = 1.0 - d / 2.0
        gamma_upper = gamma(s) * gammaincc(s, alpha)
        pref = M ** (d - 2.0) / (4.0 * np.pi) ** (d / 2.0)
        return float(pref * np.exp(alpha) * (alpha ** (d / 2.0 - 1.0)) * gamma_upper)

    @staticmethod
    def _I_4_quadrature(M: float, m: float) -> float:
        """Numerical k-integration for d=4 one-loop integral."""

        def integrand(k: float) -> float:
            if k <= 0.0:
                return 0.0
            return (k**3 / (2.0 * np.pi**2)) * np.exp(-k**2 / M**2) / (k**2 + m**2)

        val, _ = quad(integrand, 0.0, np.inf, limit=200)
        return float(val)

    def I_4_leading(self, M: float) -> tuple[float, float, float]:
        """Eq. (20): leading d=4 pieces for M >> m (see doc derivation)."""
        p = self.p
        term1 = M**2 / (4.0 * np.pi**2)
        term2 = -(p.m**2 / (4.0 * np.pi**2)) * np.log(M / p.m)
        return term1, term2, term1 + term2

    @staticmethod
    def Delta_n(n: int, d: float) -> float:
        """Engineering dimension for phi^n operator."""
        return n / 2.0 * (d - 2.0) - d

    def u_scale(self, L: float, M: float | None = None, eta_val: float | None = None) -> float:
        """d ln M / d ln L = (2η−M²)/(M²−γ) = −1/[L²(M²−γ)] on shell (M²=1/L²+2η)."""
        p = self.p
        if M is None:
            M = self.solve_M(L)
        if eta_val is None:
            eta_val = self.eta(M)
        denom = M**2 - p.gamma
        if abs(denom) < 1e-14:
            return float("nan")
        return float((2.0 * eta_val - M**2) / denom)

    def beta_phi4(self, lam: float, d: float | None = None) -> float:
        """Standard phi^4 beta(λ) = ελ − (3/16π²)λ² with ε = 4−d."""
        d = d if d is not None else self.p.d
        eps = 4.0 - d
        return float(eps * lam - (3.0 / (16.0 * np.pi**2)) * lam**2)

    def beta_tilde_lambda(
        self,
        lam_tilde: float,
        L: float,
        d: float | None = None,
    ) -> float:
        """Eq. (22): dλ/d ln L = u(L) β(λ)."""
        return self.u_scale(L) * self.beta_phi4(lam_tilde, d)

    def lambda_n_flow(
        self,
        lam_n: float,
        L: float,
        n: int,
        d: float | None = None,
    ) -> float:
        """Eq. (22): L d lambda_n / dL."""
        d = d if d is not None else self.p.d
        M = self.solve_M(L)
        eta_val = self.eta(M)
        u = self.u_scale(L, M, eta_val)
        return -self.Delta_n(n, d) * lam_n * u / L

    def lambda_star(self, d: float | None = None) -> float:
        """Non-trivial fixed point from Eq. (21)."""
        d = d if d is not None else self.p.d
        return (16.0 * np.pi**2 / 3.0) * (4.0 - d)

    @staticmethod
    def nu_mean_field(d: float, epsilon: float | None = None) -> float:
        """Mean-field nu = 1/|d-4|."""
        denom = abs(d - 4.0)
        if denom < 1e-14:
            eps = epsilon if epsilon is not None else 0.01
            return 1.0 / eps
        return 1.0 / denom

    @staticmethod
    def nu_one_loop(epsilon: float, N: float = 1.0) -> float:
        """Standard O(N) WF one-loop: nu = 1/2 + (N+2)eps/[4(N+8)].

        Ising (N=1): nu = 1/2 + eps/12.
        """
        eps = abs(epsilon) if abs(epsilon) > 1e-14 else 0.01
        return 0.5 + (N + 2.0) * eps / (4.0 * (N + 8.0))

    @staticmethod
    def nu_two_loop(epsilon: float, N: float = 1.0) -> float:
        """Standard O(N) WF two-loop truncation for nu.

        Ising (N=1): nu = 1/2 + eps/12 + 7eps^2/162 + O(eps^3).
        """
        eps = abs(epsilon) if abs(epsilon) > 1e-14 else 0.01
        c1 = (N + 2.0) / (4.0 * (N + 8.0))
        c2 = (N + 2.0) * (N * N + 23.0 * N + 60.0) / (8.0 * (N + 8.0) ** 3)
        return 0.5 + c1 * eps + c2 * (eps ** 2)

    @staticmethod
    def beta_prime_at_star(d: float) -> float:
        """β'(λ*) = −ε at the Wilson–Fisher fixed point (one-loop)."""
        eps = 4.0 - d
        lam_star = (16.0 * np.pi**2 / 3.0) * eps
        return float((4.0 - d) - (3.0 / (8.0 * np.pi**2)) * lam_star)

    @staticmethod
    def gamma_phi_star(epsilon: float) -> float:
        """Two-loop anomalous dimension η_φ* = ε²/108 (standard WF)."""
        eps = abs(epsilon) if abs(epsilon) > 1e-14 else 0.01
        return eps**2 / 108.0

    @staticmethod
    def critical_exponents_from_nu(d: float, nu: float, eta_anom: float) -> dict[str, float]:
        """Standard scaling relations."""
        beta = 0.5 * nu * (d - 2.0 + eta_anom)
        alpha = 2.0 - (d - 2.0) * nu
        return {"beta": beta, "alpha": alpha, "eta": eta_anom}

    def Lambda_eff_bh(self, R_s: float) -> float:
        """Effective cutoff at horizon with eta = alpha / R_s^2."""
        alpha = self.p.alpha_bh
        return np.sqrt((1.0 + 2.0 * alpha) / R_s**2)

    def Omega_bh(self, R_s: float) -> float:
        """Horizon dissipation factor."""
        alpha = self.p.alpha_bh
        return 1.0 - 2.0 * alpha / (R_s * (1.0 + 2.0 * alpha))

    def S_bh(self, R_s: float) -> float:
        """Eq. (25): modified Bekenstein-Hawking entropy."""
        alpha = self.p.alpha_bh
        A = 4.0 * np.pi * R_s**2
        return self.p.k_b * A / (4.0 * self.p.ell_p**2) * (1.0 + 2.0 * alpha) ** 1.5

    def dS_dt_ratio(self) -> float:
        """Eq. (26): entropy production rate enhancement."""
        alpha = self.p.alpha_bh
        return (1.0 + 2.0 * alpha) ** 1.5

    @staticmethod
    def wilson_loop_area_law(area: float, sigma0: float, Lambda_eff: float, R: float) -> float:
        """Leading area-law expectation with soft-cutoff correction."""
        correction = 1.0 + 1.0 / (Lambda_eff * R) ** 2
        return float(np.exp(-sigma0 * area * correction))

    @staticmethod
    def polyakov_screening_mass_ratio(m0: float, Lambda_eff: float) -> float:
        """Illustrative screening-mass shift from soft cutoff."""
        return float(m0 * np.sqrt(1.0 + 1.0 / Lambda_eff**2))

    # ------------------------------------------------------------------
    # U1–U8: links to literature formulas (s41467 / PR / PRL batch)
    # ------------------------------------------------------------------

    def fisher_mass(self, L: float, M: float | None = None, eta_val: float | None = None) -> float:
        """U2 (kn3z-rmm8): ignorance Fisher mass I_M = L^2/(1+2L^2 eta) = 1/M^2."""
        if M is None:
            M = self.solve_M(L)
        if eta_val is None:
            eta_val = self.eta(M)
        return float(L**2 / (1.0 + 2.0 * L**2 * eta_val))

    def fisher_flow_proxy(self, L: float) -> float:
        """Literature proxy: (d ln M / d ln L)^2 from Fisher information flow."""
        eps = max(L * 1e-4, 1e-8)
        M1 = self.solve_M(L)
        M2 = self.solve_M(L * (1.0 + eps))
        dlnM_dlnL = np.log(M2 / M1) / np.log(1.0 + eps)
        return float(dlnM_dlnL**2)

    def g_eff_soft(self, mu: float, L: float) -> float:
        """U1 (k9p6): g^2_eff = 1/(b0 ln(mu/M) Omega) with soft cutoff M(L)."""
        p = self.p
        M = self.solve_M(L)
        Om = self.Omega(L, M, self.eta(M))
        arg = mu / M
        if arg <= 1.0:
            return float("nan")
        return float(1.0 / (p.b0_qcd * np.log(arg) * Om))

    def g_eff_hard(self, mu: float, L: float) -> float:
        """Reference hard cutoff: g^2 = 1/(b0 ln(mu/L))."""
        p = self.p
        arg = mu / L
        if arg <= 1.0:
            return float("nan")
        return float(1.0 / (p.b0_qcd * np.log(arg)))

    def clock_resolution(self, L: float, M: float | None = None) -> float:
        """Effective time resolution Delta T_eff ~ L/M (rpls-mp8z mapping)."""
        if M is None:
            M = self.solve_M(L)
        return float(L / M)

    def clock_bound_lhs(self, L: float) -> float:
        """U3: (Delta T_eff)^2 * Omega(L)."""
        M = self.solve_M(L)
        Om = self.Omega(L, M, self.eta(M))
        dt = self.clock_resolution(L, M)
        return float(dt**2 * Om)

    def clock_bound_rhs(self, L: float) -> float:
        """U3 RHS proxy: 1/I_M = M^2 (Fisher mass lower bound)."""
        return float(1.0 / self.fisher_mass(L))

    def psi_LD(self, L: float) -> float:
        """U4 (PhysRevE SSEP): psi = d/d ln L ln I_d(L)."""
        eps = max(L * 1e-4, 1e-8)
        I0 = self.I_d(self.solve_M(L))
        I1 = self.I_d(self.solve_M(L * (1.0 + eps)))
        return float((np.log(I1) - np.log(I0)) / np.log(1.0 + eps))

    def psi_LD_leading(self, L: float) -> float:
        """U4 leading: psi ~ 2 * d ln M / d ln L when I ~ M^2/(4 pi^2)."""
        eps = max(L * 1e-4, 1e-8)
        M1 = self.solve_M(L)
        M2 = self.solve_M(L * (1.0 + eps))
        dlnM_dlnL = np.log(M2 / M1) / np.log(1.0 + eps)
        return float(2.0 * dlnM_dlnL)

    def beta_with_omega(self, lam_tilde: float, L: float) -> float:
        """Eq. (22): dλ/d ln L = u(L) β(λ) at scale L."""
        return self.beta_tilde_lambda(lam_tilde, L)

    def beta_standard_wilson(self, lam_tilde: float, d: float | None = None) -> float:
        """Reference β(λ) in d ln M (no u factor), for U5 comparison."""
        return self.beta_phi4(lam_tilde, d)

    def interface_dof_factor(self, R_s: float) -> float:
        """U7 (catalysis/BH): (Lambda_eff R_s)^3 = (1+2 alpha)^(3/2)."""
        alpha = self.p.alpha_bh
        return float((1.0 + 2.0 * alpha) ** 1.5)

    def S_bh_ratio(self, R_s: float) -> float:
        """U7: S_BH / S_0 = (1+2 alpha)^(3/2)."""
        S0 = self.p.k_b * 4.0 * np.pi * R_s**2 / (4.0 * self.p.ell_p**2)
        return float(self.S_bh(R_s) / S0) if S0 > 0 else float("nan")

    def phi_R_im_derivative(self, L: float) -> float:
        """Demo Im(d Phi_R / d ln L) for nonreciprocal extension (nrv2)."""
        p = self.p
        return float(p.phi_R_im_amp * np.sin(2.0 * np.pi * np.log10(max(L, 1e-12))))

    def Omega_nonreciprocal(self, L: float) -> float:
        """U8: Omega_nr = Omega + chi * Im(Phi_R')."""
        M = self.solve_M(L)
        eta_val = self.eta(M)
        Om = self.Omega(L, M, eta_val)
        return float(Om + self.p.chi_nr * self.phi_R_im_derivative(L))

    # ------------------------------------------------------------------
    # U9–U18: reference batch (Kohn/Luttinger/Lloyd/Rashba/moire/Wannier)
    # ------------------------------------------------------------------

    def M_luttinger_kohn(self, L: float) -> float:
        """U9 (Luttinger-Kohn 1955; Kohn 1957 transport): band-curvature mass shift."""
        M = self.solve_M(L)
        curv = self.p.m_band_curv
        return float(M * (1.0 + curv / (L**2 * M**2 + 1e-30)))

    def sigma_transport_correction(self, L: float) -> float:
        """U9 (Kohn 1957): higher-order conductivity correction ~ 1/(1 + gamma_scatt L^2)."""
        M = self.solve_M(L)
        return float(1.0 / (1.0 + self.p.gamma * L**2 / M**2))

    def tl_velocity(self) -> float:
        """U10 (Luttinger 1963; bonati TL spin liquid): v = v_F sqrt(1 + g^2/8)."""
        g = self.p.g_tl
        return float(self.p.v_F * np.sqrt(1.0 + g**2 / 8.0))

    def tl_K_parameter(self) -> float:
        """U10: Luttinger liquid K-parameter from interaction g."""
        g = self.p.g_tl
        return float(np.exp(-g**2 / (4.0 * np.pi)))

    def psi_TL_correction(self, L: float) -> float:
        """U10: TL correction to LD exponent psi."""
        K = self.tl_K_parameter()
        return float(0.5 * (K**2 + K**-2) - 1.0)

    def holevo_capacity_upper(self, L: float) -> float:
        """U11 (Gyongyosi survey; Lloyd 1997): C <= log(d), Fisher-limited effective capacity."""
        d = self.p.channel_dim
        I_M = self.fisher_mass(L)
        # Fisher information increases accessible rate; capped by Holevo log(d)
        return float(min(np.log(d), np.log(1.0 + I_M * max(d - 1.0, 1.0))))

    def lloyd_energy_time_bound(self, L: float) -> float:
        """U12 (Lloyd 1997): E*Delta_t >= 1/(2 I_M) in hbar=1 units."""
        I_M = self.fisher_mass(L)
        return float(0.5 / max(I_M, 1e-30))

    def rashba_splitting(self, k: float) -> float:
        """U13 (MoS2-Bi2Te3 Rashba): Delta_E = alpha_R k_eff^2, k_eff capped for numerics."""
        k_eff = min(abs(k), 5.0)
        return float(self.p.alpha_rashba * k_eff**2)

    def eta_rashba(self, L: float, k_F: float | None = None) -> float:
        """U13: Rashba contribution to effective dissipation eta."""
        M = self.solve_M(L)
        k = k_F if k_F is not None else M
        return float(self.p.alpha_rashba * k**2 / (2.0 * M**2 + 1e-30))

    def eta_valley(self, L: float, P_valley: float = 0.0) -> float:
        """U14 (valley polarization): eta_K vs eta_K' split."""
        eta = self.eta(self.solve_M(L))
        return float(eta * (1.0 + self.p.delta_valley * P_valley))

    def Omega_moire(self, L: float) -> float:
        """U15 (moire photoresponse): periodic Omega modulation in ln L."""
        p = self.p
        M = self.solve_M(L)
        Om = self.Omega(L, M, self.eta(M))
        phase = 2.0 * np.pi * np.log(max(L, 1e-12) / p.moire_L0) / p.moire_period
        return float(Om * (1.0 + p.moire_amp * np.cos(phase)))

    def wannier_k_mesh(self, L: float) -> int:
        """U16 (Winterface/Wannier90): k-mesh count from Lambda_eff."""
        M = self.solve_M(L)
        eta_val = self.eta(M)
        Lambda = self.Lambda_eff(L, eta_val)
        return int(max(1, round(Lambda * self.p.lattice_a / (2.0 * np.pi))))

    def F_ignorance(self, M2: float, L: float, T: float | None = None) -> float:
        """U17 extension: independent free energy; T=0 stationary point ≠ Eq. (15)."""
        p = self.p
        T_val = p.T_entropic if T is None else T
        if M2 <= 0:
            return np.inf
        S_eff = np.log(1.0 + M2 / p.m**2)
        return float(0.5 * L**2 * M2 - p.gamma * L**2 * np.log(M2 / p.m**2) - T_val * S_eff)

    def solve_M_entropic(self, L: float, T: float | None = None) -> float:
        """U17: global minimum of F_ignorance; T≤0 falls back to Eq. (15) solve_M."""
        p = self.p
        T_val = p.T_entropic if T is None else T
        if T_val <= 0.0:
            return self.solve_M(L)

        M_std = self.solve_M(L)
        M2_std = M_std**2

        def F(M2: float) -> float:
            return self.F_ignorance(M2, L, T_val)

        M2_lo = max(1e-20, (p.m * 1e-8) ** 2)
        M2_hi = max(M2_std * 100.0, (2.0 / L) ** 2, (p.m * 1e4) ** 2)

        res = minimize_scalar(
            F,
            bounds=(M2_lo, M2_hi),
            method="bounded",
            options={"xatol": 1e-14},
        )
        if res.success and res.x > 0 and np.isfinite(F(res.x)):
            return float(np.sqrt(res.x))

        grid = np.logspace(np.log10(M2_lo), np.log10(M2_hi), 800)
        F_vals = np.array([F(m2) for m2 in grid])
        return float(np.sqrt(grid[int(np.argmin(F_vals))]))

    def beta_open_system(self, lam_tilde: float, L: float, d: float | None = None) -> float:
        """U18 (open XY chain / Lindblad): RG with dissipation channel kappa."""
        d_val = d if d is not None else self.p.d
        kappa = self.p.kappa_diss * L**2 / (1.0 + 2.0 * L**2 * self.eta(self.solve_M(L)))
        return self.beta_tilde_lambda(lam_tilde, L, d_val) - kappa * lam_tilde

    def integrate_rg_flow_open(
        self,
        L_span: np.ndarray,
        lambda0: float,
        d: float | None = None,
    ) -> tuple[np.ndarray, np.ndarray, float]:
        """U18: RG ODE with open-system damping."""
        d_val = d if d is not None else self.p.d
        log_span = np.log(L_span)

        def rg_ode(logL: float, y: np.ndarray) -> list[float]:
            L = float(np.exp(logL))
            return [self.beta_open_system(float(y[0]), L, d_val)]

        sol = solve_ivp(
            rg_ode,
            (float(log_span[0]), float(log_span[-1])),
            [lambda0],
            t_eval=log_span,
            method="RK45",
            rtol=1e-8,
        )
        if not sol.success:
            raise RuntimeError(f"Open RG integration failed: {sol.message}")
        lam_star = self.lambda_star(d_val)
        if self.p.kappa_diss > 0:
            lam_star = lam_star / (1.0 + self.p.kappa_diss)
        return L_span, sol.y[0], float(lam_star)

    def integrate_rg_flow(
        self,
        L_span: np.ndarray,
        lambda0: float,
        d: float | None = None,
    ) -> tuple[np.ndarray, np.ndarray, float]:
        """
        Integrate Eq. (22) dλ/d ln L = u(L) β(λ).
        (From DeepSeek script: solve_ivp RG trajectory.)
        """
        d_val = d if d is not None else self.p.d
        log_span = np.log(L_span)

        def rg_ode(logL: float, y: np.ndarray) -> list[float]:
            L = float(np.exp(logL))
            lam = float(y[0])
            return [self.beta_tilde_lambda(lam, L, d_val)]

        sol = solve_ivp(
            rg_ode,
            (float(log_span[0]), float(log_span[-1])),
            [lambda0],
            t_eval=log_span,
            method="RK45",
            rtol=1e-8,
        )
        if not sol.success:
            raise RuntimeError(f"RG integration failed: {sol.message}")
        return L_span, sol.y[0], self.lambda_star(d_val)

    @staticmethod
    def kernel_momentum(k: float, L: float, eta: float) -> float:
        """Eq. (5) modulus squared (DeepSeek alias)."""
        return float(np.exp(-L**2 * k**2 / (1.0 + 2.0 * L**2 * eta)))

    def evaluate_at_L(self, L: float) -> dict[str, float]:
        """Full formula snapshot at a single scale L."""
        M = self.solve_M(L)
        eta_val = self.eta(M)
        Omega = self.Omega(L, M, eta_val)
        _, _, I4 = self.I_4_leading(M)
        return {
            "L": L,
            "M": M,
            "eta": eta_val,
            "u_scale": self.u_scale(L, M, eta_val),
            "Omega": Omega,
            "Lambda_eff": self.Lambda_eff(L, eta_val),
            "I4_leading": I4,
            "I4_leading_rel_err": self.I_4_leading_relative_error(M),
            "I_d": self.I_d(M),
            "M_small_asymp": self.M_small_asymptotic(L),
            "M_large_asymp": self.M_large_asymptotic(L),
            "I_M": self.fisher_mass(L, M, eta_val),
            "Omega_nr": self.Omega_nonreciprocal(L),
            "psi_LD": self.psi_LD(L),
            "clock_lhs": self.clock_bound_lhs(L),
            "clock_rhs": self.clock_bound_rhs(L),
            "M_LK": self.M_luttinger_kohn(L),
            "sigma_corr": self.sigma_transport_correction(L),
            "v_TL": self.tl_velocity(),
            "C_holevo": self.holevo_capacity_upper(L),
            "E_t_bound": self.lloyd_energy_time_bound(L),
            "Omega_moire": self.Omega_moire(L),
            "N_k_wannier": float(self.wannier_k_mesh(L)),
            "M_entropic": self.solve_M_entropic(L),
        }


def _annotate_v41_boundaries(
    ax,
    ff: FrameworkFormulas,
    *,
    x_lo: float | None = None,
    x_hi: float | None = None,
    shade_physical: bool = True,
) -> None:
    """Mark L_IR (eta>=0), L_safe (Omega=0), L_max (math domain) on L-axis plots."""
    L_ir = ff.L_IR()
    L_max = ff.L_max()
    L_safe = ff.L_safe()
    hi = x_hi if x_hi is not None else float(ax.get_xlim()[1])
    lo = x_lo if x_lo is not None else float(ax.get_xlim()[0])

    if shade_physical and L_ir > lo:
        ax.axvspan(lo, min(L_ir, hi), color="#238636", alpha=0.08, label=r"$\eta\ge0$ domain")
    if L_ir <= hi * (1.0 + 1e-6):
        ax.axvline(L_ir, color="#3fb950", ls="-", lw=1.5, label=rf"$L_{{\mathrm{{IR}}}}$={L_ir:.3g}")
    if L_safe <= hi * (1.0 + 1e-6):
        ax.axvline(L_safe, color="orange", ls=":", lw=1.2, label=rf"$L_{{\mathrm{{safe}}}}$={L_safe:.3g}")
    if L_max <= hi * (1.0 + 1e-6):
        ax.axvline(L_max, color="#f85149", ls="--", lw=1.2, label=rf"$L_{{\max}}$={L_max:.3g}")


def _annotate_model_boundary(ax, ff, *, label: str | None = None) -> None:
    """Legacy alias: Omega diagnostic boundaries (prefer _annotate_v41_boundaries on M plots)."""
    _annotate_v41_boundaries(ax, ff, shade_physical=False)


def export_numerical_plots(
    ff,
    profile: dict[str, np.ndarray],
    out_dir: Path,
    *,
    rg_d: float | None = None,
    lambda0: float = 0.1,
) -> list[Path]:
    """Generate PNG charts from numerical formula evaluation."""
    out_dir.mkdir(parents=True, exist_ok=True)
    plot_dir = out_dir / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []
    d_rg = rg_d if rg_d is not None else ff.p.d

    L = profile["L"]
    M = profile["M"]
    eta = profile["eta"]
    Omega = profile["Omega"]
    Lambda = profile["Lambda_eff"]

    # ------------------------------------------------------------------
    # DeepSeek-style 2×2: M, eta, Omega, Omega-1
    # ------------------------------------------------------------------
    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    axes[0, 0].loglog(L, M, "b-", lw=2)
    axes[0, 0].set_title(r"$M(L)$ — Eq. (4.1)")
    _annotate_v41_boundaries(axes[0, 0], ff, x_lo=float(L[0]), x_hi=float(L[-1]))
    axes[0, 0].legend(fontsize=6, loc="upper right")
    axes[0, 0].set_xlabel(r"$L$")
    axes[0, 0].grid(True, which="both", ls=":")

    axes[0, 1].semilogx(L, eta, "b-", lw=2)
    axes[0, 1].set_title(r"$\eta(L)$ — Eq. (4.1) closure")
    axes[0, 1].set_xlabel(r"$L$")
    axes[0, 1].grid(True, which="both", ls=":")

    axes[1, 0].semilogx(L, Omega, "b-", lw=2)
    axes[1, 0].axhline(1.0, color="r", ls="--", lw=0.8)
    axes[1, 0].axhline(0.0, color="gray", ls=":", lw=0.8)
    _annotate_model_boundary(axes[1, 0], ff)
    axes[1, 0].legend(fontsize=7, loc="lower left")
    axes[1, 0].set_title(r"$\Omega(L)$ — diagnostic (not in RG)")
    axes[1, 0].set_xlabel(r"$L$")
    axes[1, 0].grid(True, which="both", ls=":")

    axes[1, 1].semilogx(L, Omega - 1.0, "b-", lw=2)
    axes[1, 1].set_title(r"$\Omega(L)-1$ (diagnostic)")
    axes[1, 1].set_xlabel(r"$L$")
    axes[1, 1].grid(True, which="both", ls=":")
    plt.tight_layout()
    p = plot_dir / "ignorance_solution.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Eq. (4.1)+(6.1): M(L) numerical vs UV asymptotic
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.loglog(L, M, "b-", lw=2, label=r"$M(L)$ numerical (Eq. 4.1)")
    n = min(50, len(L))
    M_small = np.array([ff.M_small_asymptotic(x) for x in L[:n]])
    ax.loglog(L[:n], M_small, "r--", lw=1.5, label=r"Eq. (6.1): $1/L - \gamma L\ln(mL)$")
    M_large = np.array([ff.M_large_asymptotic(x) for x in L[-n:]])
    ok = np.isfinite(M_large) & (M_large > 0)
    if np.any(ok):
        ax.loglog(L[-n:][ok], M_large[ok], "g--", lw=1.5, label=r"large-$L$ asymp (beyond $\eta\ge0$)")
    ax.set_xlabel(r"Environmental scale $L$")
    ax.set_ylabel(r"$M(L)$")
    ax.set_title(r"Eq. (4.1): mass closure vs UV asymptotic Eq. (6.1)")
    _annotate_v41_boundaries(ax, ff, x_lo=float(L[0]), x_hi=float(L[-1]))
    ax.legend(fontsize=9)
    ax.grid(True, which="both", ls=":")
    p = plot_dir / "eq15_M_vs_L.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Eq. (14)(18): eta(L), Omega(L)
    # ------------------------------------------------------------------
    fig, axes = plt.subplots(2, 1, figsize=(8, 7), sharex=True)
    axes[0].semilogx(L, eta, "b-", lw=2)
    axes[0].axhline(0, color="gray", ls="--", lw=0.8)
    axes[0].set_ylabel(r"$\eta(L)$")
    axes[0].set_title(r"Eq. (4.1) closure: $\eta=\gamma\ln(M^2/m^2)$")
    axes[0].grid(True, which="both", ls=":")

    axes[1].semilogx(L, Omega, "b-", lw=2, label=r"$\Omega(L)$ numerical")
    axes[1].axhline(1.0, color="r", ls="--", label=r"$\Omega\to 1$ (UV)")
    axes[1].axhline(0.0, color="gray", ls=":", lw=0.8)
    _annotate_model_boundary(axes[1], ff)
    axes[1].set_xlabel(r"$L$")
    axes[1].set_ylabel(r"$\Omega(L)$")
    axes[1].set_title(r"Diagnostic $\Omega=1+(1/M^2)\,d\eta/d\ln L$ (not in RG)")
    axes[1].legend(fontsize=9)
    axes[1].grid(True, which="both", ls=":")
    plt.tight_layout()
    p = plot_dir / "eq14_18_eta_Omega_vs_L.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Eq. (3.1): Lambda_eff = M
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.loglog(L, Lambda, "purple", lw=2)
    ax.set_xlabel(r"$L$")
    ax.set_ylabel(r"$M(L)=\Lambda_{\mathrm{eff}}(L)$")
    ax.set_title(r"Eq. (3.1): $M^2=1/L^2+2\eta$  ($\equiv(1+2L^2\eta)/L^2$)")
    ax.grid(True, which="both", ls=":")
    p = plot_dir / "eq06_Lambda_eff_vs_L.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # v4.1 Eq. (3.1): M^2 = 1/L^2 + 2*eta decomposition
    # ------------------------------------------------------------------
    term_inv = 1.0 / L**2
    term_diss = 2.0 * eta
    M2_sum = term_inv + term_diss
    M2_num = M**2

    fig, axes = plt.subplots(2, 1, figsize=(8, 7), sharex=True)
    axes[0].loglog(L, term_inv, "b-", lw=2, label=r"$1/L^2$ (geometric)")
    axes[0].loglog(L, term_diss, "r-", lw=2, label=r"$2\eta(L)$ (dissipation)")
    axes[0].loglog(L, M2_sum, "k-", lw=2.5, label=r"$M^2=1/L^2+2\eta$ (sum)")
    axes[0].loglog(L, M2_num, "g--", lw=1.5, alpha=0.9, label=r"$M^2$ from Eq. (4.1) solve")
    axes[0].set_ylabel(r"$M^2$")
    axes[0].set_title(r"v4.1 Thm. 1: $M^2 = 1/L^2 + 2\eta$ — three-term decomposition")
    _annotate_v41_boundaries(axes[0], ff, x_lo=float(L[0]), x_hi=float(L[-1]))
    axes[0].legend(fontsize=8)
    axes[0].grid(True, which="both", ls=":")

    frac_diss = term_diss / (M2_sum + 1e-30)
    axes[1].semilogx(L, frac_diss, "purple", lw=2)
    axes[1].axhline(0.5, color="gray", ls=":", lw=0.8)
    axes[1].set_xlabel(r"$L$")
    axes[1].set_ylabel(r"$2\eta / M^2$")
    axes[1].set_ylim(0.0, 1.0)
    axes[1].set_title(r"Dissipation fraction $2\eta/M^2$ in effective mass")
    axes[1].grid(True, which="both", ls=":")
    plt.tight_layout()
    p = plot_dir / "eq31_M2_decomposition.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Eq. (5): |K_hat(k)|^2 vs k at sample L
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 5))
    k = np.linspace(0, 5, 300)
    sample_idx = [0, len(L) // 2, -1]
    for i in sample_idx:
        Li, Mi = float(L[i]), float(M[i])
        Kh = np.array([ff.K_hat_squared(kk, Mi) for kk in k])
        ax.plot(k, Kh, lw=2, label=rf"$L={Li:.2e},\ M={Mi:.3g}$")
    ax.set_xlabel(r"$|k|$")
    ax.set_ylabel(r"$|\hat K_L(k)|^2$")
    ax.set_title(r"Thm. 1 / Def. 3.1: $|\hat K_L(k)|^2=e^{-k^2/M^2}$")
    ax.legend(fontsize=9)
    ax.grid(True, ls=":")
    p = plot_dir / "eq05_Khat_vs_k.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Eq. (7.1): one-loop integral I_4(L)
    # ------------------------------------------------------------------
    I4_num = np.array([ff.I_d(float(m)) for m in M])
    I4_lead = np.array([ff.I_4_leading(float(m))[2] for m in M])

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.loglog(L, np.abs(I4_num), "b-", lw=2, label=r"$I_4$ numerical (Eq. 7.1)")
    ax.loglog(L, np.abs(I4_lead), "r--", lw=1.5, label=r"leading $M^2/(4\pi^2)-(m^2/4\pi^2)\ln(M/m)$")
    ax.set_xlabel(r"$L$")
    ax.set_ylabel(r"$|I_4(L)|$")
    ax.set_title(r"Eq. (7.1): one-loop $I_4$ — leading valid only for $M\gg m$")
    ax.text(
        0.02,
        0.02,
        r"Note: near $L\!\to\!L_{\mathrm{IR}}$ ($M\!\sim\!m$), leading fails; use numerical $I_4$.",
        transform=ax.transAxes,
        fontsize=8,
        color="#555555",
        va="bottom",
    )
    ax.legend(fontsize=9)
    ax.grid(True, which="both", ls=":")
    p = plot_dir / "eq19_20_I4_vs_L.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Eq. (5.2): RG beta function u(L) * beta(lambda)
    # ------------------------------------------------------------------
    lam_grid = np.linspace(0.0, 20.0, 200)
    fig, ax = plt.subplots(figsize=(8, 5))
    for i in sample_idx:
        Li = float(L[i])
        ui = float(ff.u_scale(Li))
        beta = [ff.beta_tilde_lambda(l, Li, d_rg) for l in lam_grid]
        ax.plot(lam_grid, beta, lw=2, label=rf"$L={Li:.2e},\ u={ui:.3f}$")
    lam_star = ff.lambda_star(d_rg)
    if abs(lam_star) < 25:
        ax.axvline(lam_star, color="gray", ls=":", label=rf"$\tilde\lambda_*={lam_star:.3g}$")
    ax.axhline(0, color="k", lw=0.8)
    ax.set_xlabel(r"$\tilde{\lambda}$")
    ax.set_ylabel(r"$d\tilde{\lambda}/d\ln L$")
    ax.set_title(r"Eq. (5.2): $d\lambda/d\ln L = u(L)\,\beta(\lambda)$")
    ax.legend(fontsize=8)
    ax.grid(True, ls=":")
    p = plot_dir / "eq21_rg_beta.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Eq. (5.2): RG trajectory — solve_ivp
    # ------------------------------------------------------------------
    L_path, lam_path, lam_star = ff.integrate_rg_flow(L, lambda0, d=d_rg)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.semilogx(L_path, lam_path, "b-", lw=2, label=r"$\tilde{\lambda}(L)$ ODE")
    ax.axhline(lam_star, color="r", ls="--", lw=1, label=rf"$\tilde\lambda_*={lam_star:.4g}$ (WF FP)")
    ax.set_xlabel(r"$L$")
    ax.set_ylabel(r"$\tilde{\lambda}$")
    ax.set_title(r"Eq. (5.2): RG flow (solve_ivp)")
    ax.text(
        0.02,
        0.02,
        rf"Note: $\lambda_0={lambda0:g}<\lambda^*$ $\Rightarrow$ flows away from FP (standard one-loop WF).",
        transform=ax.transAxes,
        fontsize=8,
        color="#555555",
        va="bottom",
    )
    ax.legend(fontsize=9)
    ax.grid(True, which="both", ls=":")
    p = plot_dir / "rg_flow.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.semilogx(L_path, lam_path, "b-", lw=2)
    ax.set_xlabel(r"$L$")
    ax.set_ylabel(r"$\tilde{\lambda}(L)$")
    ax.set_title(r"Eq. (5.2): RG trajectory $\tilde{\lambda}(L)$")
    ax.text(
        0.02,
        0.02,
        r"Downward flow for $\lambda_0<\lambda^*$ is expected; not a numerical error.",
        transform=ax.transAxes,
        fontsize=8,
        color="#555555",
        va="bottom",
    )
    ax.grid(True, which="both", ls=":")
    p = plot_dir / "eq21_rg_trajectory.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Eq. (25)(26) + Omega_BH: black-hole quantities vs R_s
    # ------------------------------------------------------------------
    R_s = np.logspace(-1, 2, 100)
    S_bh = np.array([ff.S_bh(r) for r in R_s])
    S_std = np.array([ff.p.k_b * 4 * np.pi * r**2 / (4 * ff.p.ell_p**2) for r in R_s])
    Om_bh = np.array([ff.Omega_bh(r) for r in R_s])

    fig, axes = plt.subplots(2, 1, figsize=(8, 7), sharex=True)
    axes[0].loglog(R_s, S_bh, "b-", lw=2, label=r"$S_{\mathrm{BH}}$ (Eq. 25)")
    axes[0].loglog(R_s, S_std, "r--", lw=1.5, label=r"$S_0$ (standard)")
    axes[0].set_ylabel(r"$S$")
    axes[0].set_title(r"Eq. (25): $S_{\mathrm{BH}}\propto A(1+2\alpha)^{3/2}$")
    axes[0].legend(fontsize=9)
    axes[0].grid(True, which="both", ls=":")

    axes[1].semilogx(R_s, Om_bh, "purple", lw=2)
    axes[1].axhline(1.0, color="r", ls="--", lw=1)
    axes[1].set_xlabel(r"$R_s$")
    axes[1].set_ylabel(r"$\Omega_{\mathrm{BH}}(R_s)$")
    axes[1].set_title(r"Horizon dissipation factor (Eq. derived)")
    axes[1].grid(True, which="both", ls=":")
    plt.tight_layout()
    p = plot_dir / "eq25_bh_entropy_vs_Rs.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # v4.1 Eq. (5.1): u(L) analytic vs numerical
    # ------------------------------------------------------------------
    u_an = np.array([ff.u_scale(float(x)) for x in L])
    u_num = np.array([ff.u_scale_numerical(float(x)) for x in L])
    rel_u = np.abs(u_an - u_num) / (np.abs(u_an) + 1e-12)

    fig, axes = plt.subplots(2, 1, figsize=(8, 7), sharex=True)
    axes[0].semilogx(L, u_an, "b-", lw=2, label=r"$u(L)$ analytic Eq. (5.1)")
    axes[0].semilogx(L, u_num, "r--", lw=1.5, markersize=3, label=r"finite-diff $d\ln M/d\ln L$")
    axes[0].axhline(-1.0, color="gray", ls=":", lw=0.8, label=r"UV limit $u\to-1$")
    axes[0].set_ylabel(r"$u(L)$")
    axes[0].set_title(r"Eq. (5.1): $u(L)=-1/[L^2(M^2-\gamma)]$")
    _annotate_v41_boundaries(axes[0], ff, x_lo=float(L[0]), x_hi=float(L[-1]))
    axes[0].legend(fontsize=8)
    axes[0].grid(True, which="both", ls=":")

    axes[1].loglog(L, rel_u, "purple", lw=2)
    axes[1].set_xlabel(r"$L$")
    axes[1].set_ylabel(r"relative $|u_{\mathrm{an}}-u_{\mathrm{num}}|/|u_{\mathrm{an}}|$")
    axes[1].grid(True, which="both", ls=":")
    plt.tight_layout()
    p = plot_dir / "eq51_u_scale_vs_L.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # v4.1 Lemma 2.1: real-space kernel |K_L(r)|^2
    # ------------------------------------------------------------------
    r = np.linspace(0.0, 3.0, 200)
    sample_L = [float(L[0]), float(L[len(L) // 2]), float(L[-1])]
    fig, ax = plt.subplots(figsize=(8, 5))
    for Li in sample_L:
        Mi = ff.solve_M(Li)
        etai = ff.eta(Mi)
        K2 = np.array([ff.K_L_real_modulus(ri, Li, etai) for ri in r])
        ax.plot(r, K2, lw=2, label=rf"$L={Li:.3g}$, $M^2={Mi**2:.3g}$")
    ax.set_xlabel(r"$r=\|z\|$")
    ax.set_ylabel(r"$|K_L(r)|$ (peak-normalized)")
    ax.set_title(r"$|K_L(r)|\propto e^{-M^2 r^2/2}$, $M^2=1/L^2+2\eta$")
    ax.legend(fontsize=9)
    ax.grid(True, ls=":")
    p = plot_dir / "eq22_lemma21_realspace_kernel.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # v4.1: critical parameters panel (lambda*, nu, domain bounds)
    # ------------------------------------------------------------------
    eps = abs(4.0 - d_rg) or 0.01
    lam_s = ff.lambda_star(d_rg)
    nu1 = ff.nu_one_loop(eps)
    nu2 = ff.nu_two_loop(eps)
    bp = ff.beta_prime_at_star(d_rg)
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.axis("off")
    table_data = [
        ["Quantity", "Symbol", "Value", "Ref."],
        [r"$\gamma$", "gamma", f"{ff.p.gamma:g}", "input"],
        [r"$m$", "m", f"{ff.p.m:g}", "input"],
        [r"$d$", "d", f"{d_rg:g}", "input"],
        [r"$\epsilon=4-d$", "eps", f"{eps:g}", "WF"],
        [r"$\lambda^*$", "lambda_star", f"{lam_s:.6g}", "Eq. (6.2)/WF"],
        [r"$\nu$ (1-loop)", "nu", f"{nu1:.6g}", "Eq. (6.2)"],
        [r"$\nu$ (2-loop)", "nu2", f"{nu2:.6g}", "Eq. (6.2)"],
        [r"$\beta'(\lambda^*)$", "beta_prime", f"{bp:.6g}", r"irrelevant $\omega$"],
        [r"$L_{\mathrm{IR}}$", "L_IR", f"{ff.L_IR():.6g}", "eta >= 0"],
        [r"$L_{\max}$", "L_max", f"{ff.L_max():.6g}", "Thm. 3"],
        [r"$L_{\mathrm{safe}}$", "L_safe", f"{ff.L_safe():.6g}", r"$\Omega=0$"],
    ]
    tbl = ax.table(
        cellText=table_data,
        loc="center",
        cellLoc="center",
        colWidths=[0.28, 0.18, 0.22, 0.22],
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(9)
    tbl.scale(1.15, 1.45)
    ax.set_title("v4.1 critical parameters & domain bounds", fontsize=12, pad=12)
    p = plot_dir / "v41_critical_parameters.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Asymptotic relative error for Eq. (6.1)
    # ------------------------------------------------------------------
    n_err = min(80, len(L))
    M_s = np.array([ff.M_small_asymptotic(x) for x in L[:n_err]])
    rel_err = np.abs(M[:n_err] - M_s) / (np.abs(M_s) + 1e-12)

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.loglog(L[:n_err], rel_err, "r-", lw=2)
    ax.set_xlabel(r"$L$")
    ax.set_ylabel(r"Relative error $|M-M_{\mathrm{asymp}}|/M_{\mathrm{asymp}}$")
    ax.set_title(r"Eq. (6.1) UV asymptotic — relative error (grows as $O(L^2)$)")
    ax.grid(True, which="both", ls=":")
    p = plot_dir / "verify_eq16_asymptotic_error.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Dashboard: all key numerical curves
    # ------------------------------------------------------------------
    fig = plt.figure(figsize=(14, 10))
    gs = GridSpec(3, 2, figure=fig, hspace=0.35, wspace=0.3)

    ax1 = fig.add_subplot(gs[0, 0])
    ax1.loglog(L, M, "b-", lw=1.5)
    _annotate_v41_boundaries(ax1, ff, x_lo=float(L[0]), x_hi=float(L[-1]))
    ax1.set_title("Eq. (4.1) $M(L)$")
    ax1.grid(True, which="both", ls=":", alpha=0.5)

    ax2 = fig.add_subplot(gs[0, 1])
    ax2.semilogx(L, Omega, "b-", lw=1.5)
    ax2.axhline(1, color="r", ls="--", lw=0.8)
    ax2.set_title(r"Diagnostic $\Omega(L)$")
    ax2.axhline(0, color="gray", ls=":", lw=0.8)
    _annotate_model_boundary(ax2, ff)
    ax2.grid(True, which="both", ls=":", alpha=0.5)

    ax3 = fig.add_subplot(gs[1, 0])
    ax3.loglog(L, Lambda, "purple", lw=1.5)
    ax3.set_title(r"Eq. (3.1) $M=\Lambda_{\mathrm{eff}}$")
    ax3.grid(True, which="both", ls=":", alpha=0.5)

    ax4 = fig.add_subplot(gs[1, 1])
    ax4.loglog(L, np.abs(I4_num), "b-", lw=1.5)
    ax4.set_title(r"Eq. (7.1) $|I_4|$ ($M\!\gg\!m$)")
    ax4.grid(True, which="both", ls=":", alpha=0.5)

    ax5 = fig.add_subplot(gs[2, 0])
    ax5.semilogx(L_path, lam_path, "b-", lw=1.5)
    ax5.set_title(r"Eq. (5.2) $\tilde{\lambda}(L)$")
    ax5.grid(True, which="both", ls=":", alpha=0.5)

    ax6 = fig.add_subplot(gs[2, 1])
    ax6.semilogx(R_s, S_bh / S_std, "b-", lw=1.5)
    ax6.axhline(ff.dS_dt_ratio(), color="r", ls="--", lw=0.8,
                label=rf"$(1+2\alpha)^{{3/2}}={ff.dS_dt_ratio():.3f}$")
    ax6.set_title(r"BH $S/S_0$ (extension; not core v4.1)")
    ax6.legend(fontsize=8)
    ax6.grid(True, which="both", ls=":", alpha=0.5)

    fig.suptitle("Unified Framework v4.1 — Numerical Formula Evaluation", fontsize=14, fontweight="bold")
    p = plot_dir / "dashboard_all_formulas.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    return saved
def export_literature_comparison_plots(
    ff,
    profile: dict[str, np.ndarray],
    out_dir: Path,
    *,
    rg_d: float | None = None,
    lambda0: float = 0.1,
) -> list[Path]:
    """Compare our formulas with literature-mapped reference forms."""
    d_rg = rg_d if rg_d is not None else ff.p.d
    if abs(d_rg - 4.0) < 1e-3:
        d_rg = 3.99  # epsilon=0.01 for visible RG flow in U18 plots
    out_dir.mkdir(parents=True, exist_ok=True)
    plot_dir = out_dir / "plots" / "literature"
    plot_dir.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []

    L = profile["L"]
    M = profile["M"]
    Omega = profile["Omega"]

    # ------------------------------------------------------------------
    # U1: soft vs hard coupling (k9p6-c649) — one panel per L
    # ------------------------------------------------------------------
    mu_grid = np.logspace(0, 3, 80)
    L_demo = [float(L[0]), float(L[len(L) // 2]), float(L[-1])]
    fig, axes = plt.subplots(1, 3, figsize=(12, 4), sharex=True)
    for ax, Li in zip(axes, L_demo):
        g_soft = np.array([ff.g_eff_soft(mu, Li) for mu in mu_grid])
        g_hard = np.array([ff.g_eff_hard(mu, Li) for mu in mu_grid])
        ok_s = np.isfinite(g_soft) & (g_soft > 0)
        ok_h = np.isfinite(g_hard) & (g_hard > 0)
        if np.any(ok_s):
            ax.loglog(mu_grid[ok_s], g_soft[ok_s], lw=2, label="soft")
        if np.any(ok_h):
            ax.loglog(mu_grid[ok_h], g_hard[ok_h], ls="--", lw=1.2, label="hard ref")
        ax.set_title(rf"$L={Li:.2e}$")
        ax.legend(fontsize=7)
        ax.grid(True, which="both", ls=":")
    axes[0].set_ylabel(r"$g^2$")
    axes[1].set_xlabel(r"$\mu$")
    fig.suptitle(
        r"U1 (k9p6): $g^2_{\mathrm{eff}}$ soft vs hard (faceted; large $L$ panel omitted from shared $y$)",
        fontsize=10,
    )
    plt.tight_layout()
    p = plot_dir / "U1_g_eff_soft_vs_hard.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # U2: Fisher mass vs flow proxy (kn3z-rmm8)
    # ------------------------------------------------------------------
    I_M = np.array([ff.fisher_mass(float(x), float(m), float(e)) for x, m, e in zip(L, M, profile["eta"])])
    I_flow = np.array([ff.fisher_flow_proxy(float(x)) for x in L])

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.loglog(L, I_M, "b-", lw=2, label=r"our $\mathcal{I}_M=1/M^2$")
    ax.loglog(L, I_flow, "r--", lw=2, label=r"lit. proxy $(d\ln M/d\ln L)^2$")
    ax.set_xlabel(r"$L$")
    ax.set_ylabel(r"Fisher-scale mass")
    ax.set_title(r"U2 (kn3z): Fisher mass vs flow proxy (comparable near $L\sim O(1)$)")
    ax.legend(fontsize=9)
    ax.grid(True, which="both", ls=":")
    p = plot_dir / "U2_fisher_mass_vs_flow.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # U3: clock bound (rpls-mp8z) — trustworthy window L <= 1.2
    # ------------------------------------------------------------------
    lhs = np.array([ff.clock_bound_lhs(float(x)) for x in L])
    rhs = np.array([ff.clock_bound_rhs(float(x)) for x in L])
    ratio = lhs / (rhs + 1e-30)
    u3_mask = L <= 1.2
    ratio_mask = L <= 1.05
    L_u3 = L[u3_mask]
    lhs_u3 = lhs[u3_mask]
    rhs_u3 = rhs[u3_mask]
    L_ratio = L[ratio_mask]
    ratio_u3 = ratio[ratio_mask]

    fig, axes = plt.subplots(2, 1, figsize=(8, 7), sharex=True)
    axes[0].loglog(L_u3, lhs_u3, "b-", lw=2, label=r"$(\Delta T_{\mathrm{eff}})^2\Omega$")
    axes[0].loglog(L_u3, rhs_u3, "r--", lw=2, label=r"$M^2=1/\mathcal{I}_M$")
    axes[0].set_ylabel("bound terms")
    axes[0].legend(fontsize=9)
    axes[0].grid(True, which="both", ls=":")
    axes[0].set_title(r"U3 (rpls-mp8z): clock bound ($L \leq 1.2$; saturates near $L \sim 1$)")

    axes[1].semilogx(L_ratio, ratio_u3, "purple", lw=2)
    axes[1].axhline(1.0, color="k", ls=":", lw=0.8)
    axes[1].set_xlim(float(L_ratio[0]), 1.05)
    axes[1].set_xlabel(r"$L$")
    axes[1].set_ylabel(r"$\mathrm{LHS}/\mathrm{RHS}$")
    axes[1].grid(True, which="both", ls=":")
    axes[1].set_title(r"Ratio $\sim 1$ near $L \sim 1$ ($L \leq 1.05$; top panel to $1.2$)")
    plt.tight_layout()
    p = plot_dir / "U3_clock_bound.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # U4: LD psi vs leading (PhysRevE SSEP)
    # ------------------------------------------------------------------
    psi_num = np.array([ff.psi_LD(float(x)) for x in L])
    psi_lead = np.array([ff.psi_LD_leading(float(x)) for x in L])

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.semilogx(L, psi_num, "b-", lw=2, label=r"$\psi=\partial_{\ln L}\ln I_d$ (numerical)")
    ax.semilogx(L, psi_lead, "r--", lw=2, label=r"leading $2\,d\ln M/d\ln L$")
    ax.set_xlabel(r"$L$")
    ax.set_ylabel(r"$\psi(L)$")
    ax.set_title("U4 (PhysRevE): large-deviation rate from one-loop integral")
    ax.legend(fontsize=9)
    ax.grid(True, which="both", ls=":")
    p = plot_dir / "U4_psi_LD_vs_leading.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # U5: v4.1 u(L)*beta vs UV reference -beta (kcm5 / SnO)
    # ------------------------------------------------------------------
    lam_grid = np.linspace(0.0, 15.0, 150)
    L5 = float(L[len(L) // 2])
    fig, ax = plt.subplots(figsize=(8, 5))
    for Li, lab in [(float(L[0]), "small L"), (L5, "mid L"), (float(L[-1]), "max L")]:
        b_v41 = [ff.beta_tilde_lambda(l, Li, d_rg) for l in lam_grid]
        ax.plot(lam_grid, b_v41, lw=2, label=rf"$u(L)\beta(\lambda)$ at {lab}")
    b_uv = [-ff.beta_standard_wilson(l, d_rg) for l in lam_grid]
    b_m = [ff.beta_standard_wilson(l, d_rg) for l in lam_grid]
    ax.plot(lam_grid, b_uv, "k--", lw=1.5, alpha=0.85, label=r"UV ref. $-\beta(\lambda)$ ($u\to-1$)")
    ax.plot(lam_grid, b_m, "gray", ls=":", lw=1.0, alpha=0.7, label=r"$d\lambda/d\ln M=\beta(\lambda)$")
    ax.axhline(0, color="k", lw=0.8)
    ax.set_xlabel(r"$\tilde{\lambda}$")
    ax.set_ylabel(r"$d\tilde{\lambda}/d\ln L$")
    ax.set_title(r"U5 (v4.1): Eq. (5.2) $u(L)\beta(\lambda)$ vs standard $\beta$")
    ax.legend(fontsize=8)
    ax.grid(True, ls=":")
    p = plot_dir / "U5_rg_beta_u_vs_Wilson.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # U7: BH entropy vs interface DOF (s63996 / catalysis)
    # ------------------------------------------------------------------
    R_s = np.logspace(-1, 1.5, 80)
    S_ratio = np.array([ff.S_bh_ratio(r) for r in R_s])
    dof = ff.interface_dof_factor(1.0)  # constant in alpha
    Om_bh = np.array([ff.Omega_bh(r) for r in R_s])

    fig, axes = plt.subplots(2, 1, figsize=(8, 7), sharex=True)
    axes[0].semilogx(R_s, S_ratio, "b-", lw=2, label=r"$S_{\mathrm{BH}}/S_0=(1+2\alpha)^{3/2}$")
    axes[0].axhline(dof, color="r", ls="--", label=rf"$(\Lambda_{{\mathrm{{eff}}}}R_s)^3={dof:.3f}$")
    axes[0].set_ylabel("entropy enhancement")
    axes[0].legend(fontsize=9)
    axes[0].grid(True, which="both", ls=":")
    axes[0].set_title("U7: Bekenstein-Hawking vs interface DOF factor (catalysis analogy)")

    axes[1].semilogx(R_s, Om_bh, "purple", lw=2)
    axes[1].axhline(1.0, color="r", ls="--")
    axes[1].set_xlabel(r"$R_s$")
    axes[1].set_ylabel(r"$\Omega_{\mathrm{BH}}(R_s)$")
    axes[1].grid(True, which="both", ls=":")
    plt.tight_layout()
    p = plot_dir / "U7_bh_interface_dof.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # U8: nonreciprocal Omega (nrv2-9h8z)
    # ------------------------------------------------------------------
    Om_nr = np.array([ff.Omega_nonreciprocal(float(x)) for x in L])
    phi_im = np.array([ff.phi_R_im_derivative(float(x)) for x in L])

    fig, axes = plt.subplots(2, 1, figsize=(8, 7), sharex=True)
    axes[0].semilogx(L, Omega, "b-", lw=2, label=r"$\Omega(L)$ reciprocal")
    axes[0].semilogx(L, Om_nr, "r-", lw=2, label=r"$\Omega_{\mathrm{nr}}$ (U8)")
    axes[0].axhline(1.0, color="gray", ls="--", lw=0.8)
    axes[0].set_ylabel(r"$\Omega$")
    axes[0].legend(fontsize=9)
    axes[0].grid(True, which="both", ls=":")
    axes[0].set_title(r"U8 (nrv2): nonreciprocal correction $\Omega_{\mathrm{nr}}=\Omega+\chi\,\mathrm{Im}\,\Phi_R'$")

    axes[1].semilogx(L, phi_im, "g-", lw=2)
    axes[1].set_xlabel(r"$L$")
    axes[1].set_ylabel(r"$\mathrm{Im}(d\Phi_R/d\ln L)$ (demo)")
    axes[1].grid(True, which="both", ls=":")
    plt.tight_layout()
    p = plot_dir / "U8_Omega_nonreciprocal.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # U9–U16: reference batch (Kohn/Luttinger/Lloyd/Rashba/moire/Wannier)
    # ------------------------------------------------------------------
    M_LK = np.array([ff.M_luttinger_kohn(float(x)) for x in L])
    sigma_c = np.array([ff.sigma_transport_correction(float(x)) for x in L])
    C_h = np.array([ff.holevo_capacity_upper(float(x)) for x in L])
    E_t = np.array([ff.lloyd_energy_time_bound(float(x)) for x in L])
    Om_m = np.array([ff.Omega_moire(float(x)) for x in L])

    fig, axes = plt.subplots(2, 2, figsize=(10, 8))
    axes[0, 0].loglog(L, M, "b-", lw=2, label=r"$M(L)$")
    axes[0, 0].loglog(L, M_LK, "r--", lw=1.5, label=r"U9 $M_{\mathrm{LK}}$")
    axes[0, 0].set_title("U9 Luttinger-Kohn mass")
    axes[0, 0].legend(fontsize=8)
    axes[0, 0].grid(True, which="both", ls=":")

    axes[0, 1].semilogx(L, sigma_c, "purple", lw=2)
    axes[0, 1].set_title("U9 Kohn transport correction")
    axes[0, 1].grid(True, which="both", ls=":")

    axes[1, 0].semilogx(L, C_h, "b-", lw=2)
    axes[1, 0].set_title("U11 Holevo capacity upper bound")
    axes[1, 0].grid(True, which="both", ls=":")

    axes[1, 1].loglog(L, E_t, "r-", lw=2)
    axes[1, 1].set_title("U12 Lloyd energy-time bound")
    axes[1, 1].grid(True, which="both", ls=":")
    plt.tight_layout()
    p = plot_dir / "U9_U12_refs_batch.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    fig, axes = plt.subplots(2, 1, figsize=(8, 6), sharex=True)
    axes[0].semilogx(L, Omega, "b-", lw=2, label=r"$\Omega$")
    axes[0].semilogx(L, Om_m, "r--", lw=2, label=r"U15 moire")
    axes[0].legend(fontsize=9)
    axes[0].set_title("U15 moire modulation")
    axes[0].grid(True, which="both", ls=":")
    Nk = np.array([ff.wannier_k_mesh(float(x)) for x in L])
    axes[1].semilogx(L, Nk, "g-", lw=2)
    axes[1].set_xlabel(r"$L$")
    axes[1].set_title("U16 Wannier k-mesh")
    axes[1].grid(True, which="both", ls=":")
    plt.tight_layout()
    p = plot_dir / "U15_U16_moire_wannier.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Summary dashboard U1–U8
    # ------------------------------------------------------------------
    fig = plt.figure(figsize=(14, 10))
    gs = GridSpec(4, 2, figure=fig, hspace=0.45, wspace=0.3)

    ax = fig.add_subplot(gs[0, 0])
    mu = np.logspace(0, 2, 50)
    Li = float(L[0])
    g_s = np.array([ff.g_eff_soft(m, Li) for m in mu])
    g_h = np.array([ff.g_eff_hard(m, Li) for m in mu])
    ok_s = np.isfinite(g_s) & (g_s > 0)
    ok_h = np.isfinite(g_h) & (g_h > 0)
    if np.any(ok_s):
        ax.loglog(mu[ok_s], g_s[ok_s], "b-", label="soft")
    if np.any(ok_h):
        ax.loglog(mu[ok_h], g_h[ok_h], "r--", label="hard")
    ax.set_title(rf"U1 $g^2_{{\mathrm{{eff}}}}$ ($L={Li:.1e}$)")
    ax.legend(fontsize=7)
    ax.grid(True, which="both", ls=":", alpha=0.5)

    ax = fig.add_subplot(gs[0, 1])
    ax.loglog(L, I_M, "b-", label=r"$\mathcal{I}_M$")
    ax.loglog(L, I_flow, "r--", label="flow")
    ax.set_title("U2 Fisher")
    ax.legend(fontsize=7)
    ax.grid(True, which="both", ls=":", alpha=0.5)

    ratio_dash = ratio[ratio_mask]
    L_ratio_dash = L[ratio_mask]
    ax = fig.add_subplot(gs[1, 0])
    ax.semilogx(L_ratio_dash, ratio_dash, "purple")
    ax.axhline(1, color="k", ls=":", lw=0.8)
    ax.set_xlim(float(L_ratio_dash[0]), 1.05)
    ax.set_title("U3 clock ratio ($L\\leq1.05$)")
    ax.grid(True, which="both", ls=":", alpha=0.5)

    ax = fig.add_subplot(gs[1, 1])
    ax.semilogx(L, psi_num, "b-", label="num")
    ax.semilogx(L, psi_lead, "r--", label="lead")
    ax.set_title("U4 $\\psi(L)$")
    ax.legend(fontsize=7)
    ax.grid(True, which="both", ls=":", alpha=0.5)

    ax = fig.add_subplot(gs[2, 0])
    ax.plot(lam_grid, [ff.beta_tilde_lambda(l, L5, d_rg) for l in lam_grid], "b-", label=r"$u\beta$ v4.1")
    ax.plot(lam_grid, [-ff.beta_standard_wilson(l, d_rg) for l in lam_grid], "r--", label=r"$-\beta$ UV")
    ax.set_title("U5 RG beta (v4.1)")
    ax.legend(fontsize=7)
    ax.grid(True, ls=":", alpha=0.5)

    ax = fig.add_subplot(gs[2, 1])
    ax.semilogx(R_s, S_ratio, "b-")
    ax.axhline(dof, color="r", ls="--")
    ax.set_title("U7 $S/S_0$")
    ax.grid(True, which="both", ls=":", alpha=0.5)

    ax = fig.add_subplot(gs[3, :])
    ax.semilogx(L, Omega, "b-", lw=2, label=r"$\Omega$")
    ax.semilogx(L, Om_nr, "r-", lw=2, label=r"$\Omega_{\mathrm{nr}}$")
    ax.set_xlabel(r"$L$")
    ax.set_title("U8 nonreciprocal extension")
    ax.legend(fontsize=8)
    ax.grid(True, which="both", ls=":", alpha=0.5)

    fig.suptitle("Literature–Framework Formula Links (U1–U8)", fontsize=14, fontweight="bold")
    p = plot_dir / "dashboard_U1_U8.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # U17: entropic correction to Eq. (15) — dedicated comparison
    # ------------------------------------------------------------------
    M_ent = np.array([ff.solve_M_entropic(float(x)) for x in L])
    rel_u17 = np.abs(M_ent - M) / (M + 1e-30)

    fig, axes = plt.subplots(2, 2, figsize=(11, 9))
    axes[0, 0].loglog(L, M, "b-", lw=2, label=r"$M(L)$ Eq. (4.1)")
    axes[0, 0].loglog(L, M_ent, "r--", lw=2, label=rf"$M_{{\mathrm{{ent}}}}$, $T={ff.p.T_entropic}$")
    axes[0, 0].set_title("U17: Eq. (4.1) vs entropic extension (independent $T>0$ model)")
    axes[0, 0].legend(fontsize=8)
    axes[0, 0].grid(True, which="both", ls=":")

    axes[0, 1].semilogx(L, rel_u17, "purple", lw=2)
    axes[0, 1].set_ylabel(r"$|M-M_{\mathrm{ent}}|/M$")
    axes[0, 1].set_title("U17 relative deviation")
    axes[0, 1].grid(True, which="both", ls=":")

    L_demo = float(L[len(L) // 2])
    T_hi = max(ff.p.T_entropic * 3, 0.03)
    T_lo = max(T_hi * 0.02, ff.p.T_entropic * 0.05, 1e-4)
    T_grid = np.linspace(T_lo, T_hi, 40)
    M_vs_T = np.array([ff.solve_M_entropic(L_demo, T=float(t)) for t in T_grid])
    M_eq15 = ff.solve_M(L_demo)
    axes[1, 0].plot(T_grid, M_vs_T, "g-", lw=2, label=rf"$M_{{\mathrm{{ent}}}}(T)$, $T>0$")
    axes[1, 0].axhline(M_eq15, color="b", ls="--", label=rf"Eq. (4.1) at $T=0$ ($M={M_eq15:.3g}$)")
    axes[1, 0].set_xlim(T_lo, T_hi)
    axes[1, 0].set_xlabel(r"$T$")
    axes[1, 0].set_ylabel(r"$M_{\mathrm{ent}}(L)$")
    axes[1, 0].set_title(rf"U17 $M(T)$ at $L={L_demo:.3g}$ (entropic branch only)")
    axes[1, 0].legend(fontsize=7)
    axes[1, 0].grid(True, ls=":")

    M2_scan = np.logspace(-4, 4, 300)
    F0 = np.array([ff.F_ignorance(m2, L_demo, T=0.0) for m2 in M2_scan])
    FT = np.array([ff.F_ignorance(m2, L_demo, T=ff.p.T_entropic) for m2 in M2_scan])
    axes[1, 1].semilogx(M2_scan, F0, "b-", lw=1.5, label=r"$T=0$")
    axes[1, 1].semilogx(M2_scan, FT, "r--", lw=1.5, label=rf"$T={ff.p.T_entropic}$")
    axes[1, 1].set_xlabel(r"$M^2$")
    axes[1, 1].set_title(rf"U17 $\mathcal{{F}}(M^2)$ at $L={L_demo:.3g}$")
    axes[1, 1].legend(fontsize=8)
    axes[1, 1].grid(True, which="both", ls=":")
    plt.tight_layout()
    p = plot_dir / "U17_entropic_mass_comparison.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # U18: closed vs open RG flow — dedicated comparison
    # ------------------------------------------------------------------
    L_path, lam_closed, star_c = ff.integrate_rg_flow(L, lambda0, d=d_rg)
    L_path_o, lam_open, star_o = ff.integrate_rg_flow_open(L, lambda0, d=d_rg)

    fig, axes = plt.subplots(2, 2, figsize=(11, 9))
    axes[0, 0].semilogx(L_path, lam_closed, "b-", lw=2, label="closed Eq. (5.2)")
    axes[0, 0].semilogx(L_path_o, lam_open, "r--", lw=2, label=rf"open, $\kappa={ff.p.kappa_diss}$")
    axes[0, 0].axhline(star_c, color="b", ls=":", lw=1, label=rf"$\tilde\lambda_*^{{\mathrm{{cl}}}}={star_c:.3g}$")
    axes[0, 0].axhline(star_o, color="r", ls=":", lw=1, label=rf"$\tilde\lambda_*^{{\mathrm{{op}}}}={star_o:.3g}$")
    axes[0, 0].set_xlabel(r"$L$")
    axes[0, 0].set_ylabel(r"$\tilde{\lambda}(L)$")
    axes[0, 0].set_title(rf"U18 RG trajectory ($d={d_rg:.4g}$)")
    axes[0, 0].legend(fontsize=7)
    axes[0, 0].grid(True, which="both", ls=":")

    diff_lam = lam_open - lam_closed
    axes[0, 1].semilogx(L_path, diff_lam, "purple", lw=2)
    axes[0, 1].axhline(0, color="k", lw=0.8)
    axes[0, 1].set_title(r"U18 $\tilde{\lambda}_{\mathrm{open}}-\tilde{\lambda}_{\mathrm{closed}}$")
    axes[0, 1].grid(True, which="both", ls=":")

    L_beta = float(L[len(L) // 2])
    lam_grid = np.linspace(0.0, min(star_c * 2.5, 25.0) if star_c > 0 else 5.0, 120)
    if star_c <= 0:
        lam_grid = np.linspace(0.0, 5.0, 120)
    beta_c = np.array([ff.beta_tilde_lambda(l, L_beta, d_rg) for l in lam_grid])
    beta_o = np.array([ff.beta_open_system(l, L_beta, d_rg) for l in lam_grid])
    axes[1, 0].plot(lam_grid, beta_c, "b-", lw=2, label=r"$u\beta$ closed")
    axes[1, 0].plot(lam_grid, beta_o, "r--", lw=2, label=r"open $-\kappa\tilde\lambda$")
    axes[1, 0].axhline(0, color="k", lw=0.8)
    axes[1, 0].set_xlabel(r"$\tilde{\lambda}$")
    axes[1, 0].set_title(rf"U18 beta at $L={L_beta:.3g}$")
    axes[1, 0].legend(fontsize=8)
    axes[1, 0].grid(True, ls=":")

    kappa_L = np.array([
        ff.p.kappa_diss * x**2 / (1.0 + 2.0 * x**2 * ff.eta(ff.solve_M(float(x))))
        for x in L
    ])
    axes[1, 1].loglog(L, kappa_L, "orange", lw=2)
    axes[1, 1].set_xlabel(r"$L$")
    axes[1, 1].set_ylabel(r"$\kappa(L)$")
    axes[1, 1].set_title(r"U18 damping channel $\kappa(L)=\kappa_0 L^2/(1+2L^2\eta)$")
    axes[1, 1].grid(True, which="both", ls=":")
    plt.tight_layout()
    p = plot_dir / "U18_open_rg_comparison.png"
    fig.savefig(p, dpi=200, bbox_inches="tight")
    plt.close(fig)
    saved.append(p)

    return saved



def _export_xlsx(path: Path, sheets: dict[str, pd.DataFrame], meta: dict | None = None) -> Path:
    """Write one or more DataFrames to an .xlsx workbook (openpyxl)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        if meta:
            pd.DataFrame([meta]).T.rename(columns={0: "value"}).to_excel(
                writer, sheet_name="parameters"
            )
        for name, df in sheets.items():
            safe = str(name)[:31]
            df.to_excel(writer, sheet_name=safe, index=False)
    return path


def export_paper_figures(
    ff: FrameworkFormulas,
    profile: dict[str, np.ndarray],
    out_dir: Path,
    *,
    rg_d: float | None = None,
    lambda0: float = 0.1,
) -> list[Path]:
    """Six journal-style figures for v4.1 (English captions; no dashboards / U-series)."""
    paper_dir = out_dir / "paper_figures"
    paper_dir.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []
    d_rg = rg_d if rg_d is not None else ff.p.d
    L_ir = ff.L_IR()

    L = profile["L"]
    M = profile["M"]
    eta = profile["eta"]

    # Colorblind-friendly palette
    c_blue = "#0072B2"
    c_orange = "#E69F00"
    c_green = "#009E73"
    c_black = "#000000"
    c_gray = "#666666"

    plt.rcParams.update({
        "font.family": "serif",
        "font.size": 11,
        "axes.labelsize": 12,
        "axes.titlesize": 12,
        "legend.fontsize": 9,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "xtick.direction": "in",
        "ytick.direction": "in",
        "xtick.top": True,
        "ytick.right": True,
        "axes.linewidth": 1.0,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
    })

    def mark_L_IR(ax, y_point: float | None = None) -> None:
        ax.axvline(L_ir, color=c_green, ls="--", lw=1.4, label=rf"$L_{{\mathrm{{IR}}}}=1/m_R={L_ir:g}$")
        if y_point is not None:
            # use scatter (not plot) so a single marker cannot spawn a stray line/ghost on log axes
            ax.scatter(
                [L_ir],
                [y_point],
                marker="*",
                s=220,
                c="#D55E00",
                edgecolors="k",
                linewidths=0.8,
                zorder=10,
                label=r"IR point ($M=m_R$)",
            )

    # ------------------------------------------------------------------
    # Fig. 1 — Lemma 2.1: real-space kernel
    # ------------------------------------------------------------------
    r = np.linspace(0.0, 3.0, 400)
    sample_L = [float(L[0]), float(L[len(L) // 2]), float(L[-1])]
    fig, ax = plt.subplots(figsize=(5.2, 3.8))
    styles = [(c_blue, "-"), (c_orange, "-"), (c_green, "-")]
    for Li, (col, ls) in zip(sample_L, styles):
        Mi = ff.solve_M(Li)
        etai = ff.eta(Mi)
        K2 = np.array([ff.K_L_real_modulus(ri, Li, etai) for ri in r])
        ax.plot(r, K2, color=col, ls=ls, lw=2.0, label=rf"$L={Li:.3g}$, $M={Mi:.3g}$")
    ax.set_xlabel(r"$r=\|z\|$")
    ax.set_ylabel(r"$|K_L(r)|$ (peak-normalized)")
    ax.set_title("Minimal holomorphic kernel")
    ax.legend(frameon=False)
    ax.grid(True, ls=":", alpha=0.5)
    p = paper_dir / "fig1_realspace_kernel.png"
    fig.savefig(p)
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Fig. 2 — Def. 3.1 / Thm. 1: momentum-space kernel
    # ------------------------------------------------------------------
    k = np.linspace(0.0, 5.0, 400)
    fig, ax = plt.subplots(figsize=(5.2, 3.8))
    for Li, (col, ls) in zip(sample_L, styles):
        Mi = ff.solve_M(Li)
        Kh = np.array([ff.K_hat_squared(kk, Mi) for kk in k])
        ax.plot(k, Kh, color=col, ls=ls, lw=2.0, label=rf"$L={Li:.3g}$, $M={Mi:.3g}$")
    ax.set_xlabel(r"$|k|$")
    ax.set_ylabel(r"$|\hat{K}_L(k)|^2$")
    ax.set_title(r"Momentum-space cutoff $|\hat{K}_L|^2=e^{-k^2/M^2}$")
    ax.legend(frameon=False)
    ax.grid(True, ls=":", alpha=0.5)
    p = paper_dir / "fig2_momentum_kernel.png"
    fig.savefig(p)
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Fig. 3 — Thm. 1: M^2 = 1/L^2 + 2 eta
    # ------------------------------------------------------------------
    term_inv = 1.0 / L**2
    term_diss = 2.0 * eta
    M2_sum = term_inv + term_diss
    fig, ax = plt.subplots(figsize=(5.2, 3.8))
    ax.loglog(L, term_inv, color=c_blue, lw=2.0, label=r"$1/L^2$")
    ax.loglog(L, term_diss, color=c_orange, lw=2.0, label=r"$2\eta_{\mathrm{eff}}(L)$")
    ax.loglog(L, M2_sum, color=c_black, lw=2.2, label=r"$M^2=1/L^2+2\eta_{\mathrm{eff}}$")
    ax.loglog(L, M**2, color=c_green, ls="--", lw=1.5, label=r"$M^2$ from closure")
    mark_L_IR(ax, y_point=float(ff.p.m**2))
    ax.set_xlim(L[0], max(L[-1], L_ir * 1.05))
    ax.set_xlabel(r"Environmental scale $L$")
    ax.set_ylabel(r"$M^2$")
    ax.set_title(r"Effective-mass decomposition")
    ax.legend(frameon=False, loc="upper right", markerscale=1.2)
    ax.grid(True, which="both", ls=":", alpha=0.5)
    p = paper_dir / "fig3_M2_decomposition.png"
    fig.savefig(p, dpi=300, bbox_inches="tight", pad_inches=0.15)
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Fig. 4 — Thm. 2–4: M(L) + UV asymptotic + L_IR
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(5.2, 3.8))
    ax.loglog(L, M, color=c_blue, lw=2.2, label=r"$M(L)$")
    n = min(80, len(L))
    M_small = np.array([ff.M_small_asymptotic(float(x)) for x in L[:n]])
    ax.loglog(L[:n], M_small, color=c_orange, ls="--", lw=1.8, label=r"UV asymptotic")
    mark_L_IR(ax, y_point=float(ff.p.m))
    ax.set_xlabel(r"Environmental scale $L$")
    ax.set_ylabel(r"$M(L)$")
    ax.set_title(r"Closure solution and infrared endpoint")
    ax.legend(frameon=False)
    ax.grid(True, which="both", ls=":", alpha=0.5)
    p = paper_dir / "fig4_M_vs_L_domain.png"
    fig.savefig(p, dpi=300, bbox_inches="tight", pad_inches=0.15)
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Fig. 5 — Thm. 5: u(L)
    # ------------------------------------------------------------------
    u_an = np.array([ff.u_scale(float(x)) for x in L])
    u_num = np.array([ff.u_scale_numerical(float(x)) for x in L])
    u_ir = float(ff.u_scale(float(L_ir)))
    fig, ax = plt.subplots(figsize=(5.2, 3.8))
    ax.semilogx(L, u_an, color=c_blue, lw=2.2, label=r"$u(L)$ analytic")
    ax.semilogx(L, u_num, color=c_orange, ls="--", lw=1.6, label=r"finite difference")
    ax.axhline(-1.0, color=c_gray, ls=":", lw=1.2, label=r"UV limit $u\to-1$")
    mark_L_IR(ax, y_point=u_ir)
    ax.set_xlabel(r"Environmental scale $L$")
    ax.set_ylabel(r"$u=d\ln M/d\ln L$")
    ax.set_title(r"Scale Jacobian $u(L)$")
    ax.legend(frameon=False, loc="lower left")
    ax.grid(True, which="both", ls=":", alpha=0.5)
    fig.subplots_adjust(left=0.16, right=0.98, bottom=0.14, top=0.90)
    p = paper_dir / "fig5_u_scale.png"
    fig.savefig(p, dpi=300, bbox_inches="tight", pad_inches=0.22)
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Fig. 6 — mid-scale RG mismatch Delta = (u+1) beta
    # Absolute u*beta curves nearly coincide with -beta; plot Delta only.
    # ------------------------------------------------------------------
    lam_grid = np.linspace(0.0, 12.0, 250)
    L_uv = float(L[0])
    L_mid = 0.3
    L_near = 0.7
    beta = np.array([ff.beta_phi4(l, d_rg) for l in lam_grid])
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    for Lv, col, ls in (
        (L_uv, c_blue, "--"),
        (L_mid, c_orange, "-"),
        (L_near, c_green, "-"),
    ):
        uL = float(ff.u_scale(Lv))
        ax.plot(
            lam_grid,
            (uL + 1.0) * beta,
            color=col,
            ls=ls,
            lw=2.0,
            label=rf"$\Delta$ at $L={Lv:g}$ ($u+1={uL+1.0:.3g}$)",
        )
    ax.axhline(0.0, color=c_black, lw=0.8)
    lam_star = ff.lambda_star(d_rg)
    if abs(lam_star) > 1e-12:
        ax.axvline(lam_star, color=c_gray, ls=":", lw=1.2, label=rf"$\lambda^*\approx{lam_star:.3g}$")
    ax.set_xlabel(r"$\tilde{\lambda}$")
    ax.set_ylabel(r"$\Delta=(u+1)\beta(\tilde\lambda)$")
    ax.set_title(r"Mid-scale RG mismatch $\Delta=u\beta-(-\beta)$")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(True, ls=":", alpha=0.5)
    fig.subplots_adjust(left=0.16, right=0.98, bottom=0.14, top=0.90)
    p = paper_dir / "fig6_rg_beta.png"
    fig.savefig(p, dpi=300, bbox_inches="tight", pad_inches=0.25)
    plt.close(fig)
    saved.append(p)

    # ------------------------------------------------------------------
    # Fig. 7 — Application: ν vs literature (3D Ising / XY)
    # Framework inherits standard Wilson–Fisher ε-expansion (Theorem 9).
    # ------------------------------------------------------------------
    # Literature (commonly cited MC / bootstrap anchors):
    #   3D Ising: Hasenbusch, Phys. Rev. B 82, 174433 (2010) ν=0.63002(10)
    #   3D XY:    Campostrini et al. / Goldner et al. ν≈0.67155–0.6717
    nu_mf = 0.5
    nu_1l = float(ff.nu_one_loop(1.0))   # ε=1 → d=3
    nu_2l = float(ff.nu_two_loop(1.0))
    nu_ising = 0.63002
    nu_xy = 0.67155

    labels = [
        "Mean\nfield",
        "Ising WF\n1-loop (raw)",
        "Ising WF\n2-loop (raw)",
        "3D Ising\n(MC lit.)",
        "3D XY\n(MC lit.)",
    ]
    values = [nu_mf, nu_1l, nu_2l, nu_ising, nu_xy]
    colors = [c_gray, c_blue, "#56B4E9", c_orange, c_green]

    fig, ax = plt.subplots(figsize=(6.2, 3.9))
    x = np.arange(len(labels))
    bars = ax.bar(x, values, color=colors, edgecolor="black", linewidth=0.6, width=0.72)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_ylabel(r"Correlation-length exponent $\nu$")
    ax.set_title(r"Inherited Wilson--Fisher (illustrative only; not a new prediction)")
    ax.set_ylim(0.45, 0.95)
    ax.axhline(nu_ising, color=c_orange, ls=":", lw=1.0, alpha=0.7)
    ax.axhline(nu_xy, color=c_green, ls=":", lw=1.0, alpha=0.7)
    for bar, val in zip(bars, values):
        ax.text(
            bar.get_x() + bar.get_width() / 2.0,
            val + 0.012,
            f"{val:.4f}",
            ha="center",
            va="bottom",
            fontsize=8,
        )
    ax.text(
        0.02,
        0.98,
        r"Framework $=$ standard WF $\varepsilon$-expansion (Thm.~9);"
        "\n"
        r"raw $\varepsilon=1$ series is poorly convergent vs MC.",
        transform=ax.transAxes,
        fontsize=8,
        color="#444444",
        va="top",
    )
    ax.grid(True, axis="y", ls=":", alpha=0.5)
    fig.tight_layout()
    p = paper_dir / "fig7_nu_application.png"
    fig.savefig(p)
    plt.close(fig)
    saved.append(p)


    # ------------------------------------------------------------------
    # Excel tables (one workbook per figure + combined workbook)
    # ------------------------------------------------------------------
    meta = {
        "model_version": "v4.1",
        "gamma": float(ff.p.gamma),
        "m": float(ff.p.m),
        "d_rg": float(d_rg),
        "epsilon": float(abs(4.0 - d_rg) or 0.01),
        "L_IR": float(L_ir),
        "L_min": float(L[0]),
        "L_max_scan": float(L[-1]),
        "sample_L": ",".join(f"{x:.6g}" for x in sample_L),
    }

    # Fig.1 long table
    rows1 = []
    for Li in sample_L:
        Mi = float(ff.solve_M(Li))
        etai = float(ff.eta(Mi))
        for ri in r:
            rows1.append({
                "L": Li,
                "M": Mi,
                "eta": etai,
                "r": float(ri),
                "K_L_r_squared_peak_norm": float(ff.K_L_real_modulus(float(ri), Li, etai)),
            })
    df1 = pd.DataFrame(rows1)

    # Fig.2
    rows2 = []
    for Li in sample_L:
        Mi = float(ff.solve_M(Li))
        for kk in k:
            rows2.append({
                "L": Li,
                "M": Mi,
                "k": float(kk),
                "Khat_squared": float(ff.K_hat_squared(float(kk), Mi)),
            })
    df2 = pd.DataFrame(rows2)

    # Fig.3
    df3 = pd.DataFrame({
        "L": L,
        "inv_L2": term_inv,
        "two_eta": term_diss,
        "M2_sum_1_over_L2_plus_2eta": M2_sum,
        "M2_from_closure": M**2,
        "M": M,
        "eta": eta,
    })

    # Fig.4
    M_asymp_full = np.full(len(L), np.nan)
    M_asymp_full[:n] = M_small
    df4 = pd.DataFrame({
        "L": L,
        "M_closure": M,
        "M_UV_asymptotic": M_asymp_full,
        "L_IR": L_ir,
    })

    # Fig.5
    df5 = pd.DataFrame({
        "L": L,
        "u_analytic": u_an,
        "u_finite_difference": u_num,
        "u_UV_limit": -1.0,
    })

    # Fig.6
    u_uv = float(ff.u_scale(L_uv))
    u_mid = float(ff.u_scale(L_mid))
    u_near = float(ff.u_scale(L_near))
    df6 = pd.DataFrame({
        "lambda_tilde": lam_grid,
        "Delta_at_L_uv": (u_uv + 1.0) * beta,
        "Delta_at_L_mid": (u_mid + 1.0) * beta,
        "Delta_at_L_near": (u_near + 1.0) * beta,
        "beta": beta,
        "lambda_star": lam_star,
        "L_uv": L_uv,
        "L_mid": L_mid,
        "L_near": L_near,
    })

    # Fig.7
    df7 = pd.DataFrame({
        "label": [
            "Mean field",
            "Ising WF 1-loop (raw)",
            "Ising WF 2-loop (raw)",
            "3D Ising (MC lit.)",
            "3D XY (MC lit.)",
        ],
        "nu": values,
        "note": [
            "nu=1/2",
            "Ising N=1: 1/2+eps/12 (inheritance, not a new prediction)",
            "Ising N=1: 1/2+eps/12+7eps^2/162 (inheritance, not a new prediction)",
            "Hasenbusch PRB 82,174433 (2010)",
            "Campostrini et al. PRB 63,214503 (2001)",
        ],
        "epsilon": [1.0] * 5,
        "d": [3.0] * 5,
    })

    xlsx_specs = [
        ("fig1_realspace_kernel.xlsx", {"Fig1_kernel_real": df1}),
        ("fig2_momentum_kernel.xlsx", {"Fig2_kernel_mom": df2}),
        ("fig3_M2_decomposition.xlsx", {"Fig3_M2_decomp": df3}),
        ("fig4_M_vs_L_domain.xlsx", {"Fig4_M_vs_L": df4}),
        ("fig5_u_scale.xlsx", {"Fig5_u_scale": df5}),
        ("fig6_rg_beta.xlsx", {"Fig6_rg_beta": df6}),
        ("fig7_nu_application.xlsx", {"Fig7_nu": df7}),
    ]
    for fname, sheets in xlsx_specs:
        xp = _export_xlsx(paper_dir / fname, sheets, meta=meta)
        saved.append(xp)

    combined = {
        "Fig1_kernel_real": df1,
        "Fig2_kernel_mom": df2,
        "Fig3_M2_decomp": df3,
        "Fig4_M_vs_L": df4,
        "Fig5_u_scale": df5,
        "Fig6_rg_beta": df6,
        "Fig7_nu": df7,
    }
    xp = _export_xlsx(paper_dir / "paper_figures_data.xlsx", combined, meta=meta)
    saved.append(xp)

    # Captions file (English)
    eps = abs(4.0 - d_rg) or 0.01
    captions = f"""paper_figures — Ignorance-Boundary Unified Field Framework v4.1
Parameters: gamma={ff.p.gamma:g}, m={ff.p.m:g}, d={d_rg:g} (epsilon={eps:g}), L in [{float(L[0]):.3g}, {float(L[-1]):.3g}].

Fig. 1 (fig1_realspace_kernel.png)
Caption: Real-space kernel modulus |K_L(r)| ∝ exp(−M^2 r^2/2) with M^2 = 1/L^2 + 2η
(not |K|^2). Larger M (smaller L) yields a narrower kernel.

Fig. 2 (fig2_momentum_kernel.png)
Caption: Momentum-space cutoff |K̂_L(k)|^2 = exp(−k^2/M^2) (Definition 3.1 / Theorem 1)
for the same scales as in Fig. 1. As M decreases toward the infrared, the soft cutoff
becomes stronger at fixed |k|.

Fig. 3 (fig3_M2_decomposition.png)
Caption: Three-term decomposition of the effective mass, M^2 = 1/L^2 + 2η(L)
(Theorem 1). The geometric term 1/L^2 dominates over most of the physical domain;
the dashed green curve is M^2 obtained by solving the closure equation (4.1).
The vertical line marks the physical infrared boundary L_IR = 1/m (eta >= 0).

Fig. 4 (fig4_M_vs_L_domain.png)
Caption: Self-consistent mass M(L) from the closure equation (4.1) compared with the
ultraviolet asymptotic expansion (6.1). The physical domain is restricted to L ≤ L_IR
so that η ≥ 0 (physical domain).

Fig. 5 (fig5_u_scale.png)
Caption: Physical scale derivative u(L) = d ln M / d ln L from the implicit-function
formula (5.1), compared with a centered finite-difference estimate. In the ultraviolet,
u → −1; the infrared boundary L_IR is indicated by the dashed green line.

Fig. 6 (fig6_rg_beta.png)
Caption: One-loop RG beta in observation-scale time, dλ/d ln L = u(L) β(λ)
(Equation 5.2), at ultraviolet and intermediate L. The gray dashed curve is the
ultraviolet reference −β(λ) corresponding to u → −1. The vertical dotted line marks
the Wilson–Fisher fixed point λ*.

Fig. 7 (fig7_nu_application.png)
Caption: Application figure for the correlation-length exponent ν in d=3 (ε=1).
Bars show mean-field ν=1/2, the present framework's one- and two-loop Wilson–Fisher
ε-expansion values (Theorem 9: identical to standard WF), and literature Monte Carlo
anchors for the 3D Ising class [ν≈0.63002, Hasenbusch, Phys. Rev. B 82, 174433 (2010)]
and the 3D XY class [ν≈0.67155, Campostrini et al.]. The raw ε=1 truncations are not
expected to match high-precision MC; the figure documents inheritance of the standard
universality class rather than a new one.
"""
    (paper_dir / "captions_en.txt").write_text(captions, encoding="utf-8")
    saved.append(paper_dir / "captions_en.txt")

    refs = """References for Fig. 7 (nu comparison)
------------------------------------
3D Ising nu = 0.63002(10)
  M. Hasenbusch, Phys. Rev. B 82, 174433 (2010).

3D XY nu ≈ 0.67155(27)
  M. Campostrini, M. Hasenbusch, A. Pelissetto, P. Rossi, E. Vicari,
  Phys. Rev. B 63, 214503 (2001); see also Goldner et al.,
  Phys. Rev. B 71, 220402(R) (2005) [nu=0.6717(3)].

Framework formulas = standard Ising (N=1) Wilson-Fisher (NOT a new prediction):
  nu = 1/2 + eps/12 + O(eps^2)                      (one loop)
  nu = 1/2 + eps/12 + 7*eps^2/162 + O(eps^3)        (two loop)
  with eps = 4 - d = 1 for d = 3
  => nu^(1) = 0.583333..., nu^(2) = 0.626543...

NOTE: Do NOT use the incorrect misremembered forms
  1/2 + eps/4  or  1/2 + eps/4 + eps^2/8.
"""
    (paper_dir / "fig7_references.txt").write_text(refs, encoding="utf-8")
    saved.append(paper_dir / "fig7_references.txt")

    # restore a mild default (avoid polluting later plots too much)
    plt.rcParams.update(plt.rcParamsDefault)
    matplotlib.use("Agg")

    return saved


ROOT = Path(__file__).resolve().parent
DEFAULT_OUT = ROOT / "output"


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Unified field framework — formula calculator & plots.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--gamma", type=float, default=0.05, help="Universal constant gamma")
    parser.add_argument("--m", type=float, default=1.0, help="IR reference mass")
    parser.add_argument("--d", type=float, default=4.0, help="Spacetime dimension for RG")
    parser.add_argument(
        "--rg-epsilon",
        type=float,
        default=0.01,
        help="RG uses d=4-epsilon (default 0.01 -> d=3.99 for visible U18 flow)",
    )
    parser.add_argument("--alpha-bh", type=float, default=0.1, help="Black-hole dissipation alpha")
    parser.add_argument("--L-min", type=float, default=1e-3, help="Minimum L for profile scan")
    parser.add_argument("--L-max", type=float, default=1e3, help="Requested maximum L")
    parser.add_argument("--n-points", type=int, default=400, help="Points in L profile")
    parser.add_argument("--lambda0", type=float, default=0.1, help="Initial RG coupling for ODE")
    parser.add_argument(
        "--T-entropic",
        type=float,
        default=0.01,
        help="U17 entropic temperature (T<=0: Eq.15 only; T>0: independent F_ignorance extension)",
    )
    parser.add_argument(
        "--kappa-diss",
        type=float,
        default=0.05,
        help="U18 open-system RG damping strength",
    )
    parser.add_argument("--L", type=float, nargs="*", help="Evaluate at specific L values")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUT, help="Output directory")
    parser.add_argument("--no-plots", action="store_true", help="Skip plot export")
    parser.add_argument("--latex-images", action="store_true", help="Export LaTeX formula PNGs")
    parser.add_argument("--latex", action="store_true", help="Export paper_equations.tex")
    parser.add_argument("--no-export", action="store_true", help="Skip JSON/CSV export")
    parser.add_argument("--summary-only", action="store_true", help="Print summary only")
    parser.add_argument(
        "--paper-figures",
        action="store_true",
        help="Export 6 journal-style figures to output/paper_figures/ (English captions)",
    )
    parser.add_argument(
        "--paper-only",
        action="store_true",
        help="Only export paper_figures (skip dashboards / U-series / JSON)",
    )
    parser.add_argument(
        "--quantum",
        action="store_true",
        help="Run Caldeira-Leggett / Ohmic quantum open-system layer (quantum_open_system.py)",
    )
    parser.add_argument(
        "--quantum-only",
        action="store_true",
        help="Only run the quantum layer (skip classical mid-scale export)",
    )
    return parser.parse_args(argv)


def build_L_grid(ff: FrameworkFormulas, args: argparse.Namespace) -> np.ndarray:
    if args.L:
        L_max = ff.L_max()
        for L in args.L:
            if L > L_max:
                print(f"[WARN] L={L} exceeds L_max={L_max:.6g}", file=sys.stderr)
        return np.array(sorted(args.L), dtype=float)

    L_hi = min(args.L_max, ff.L_safe(), ff.L_IR())
    if args.L_max > L_hi:
        print(
            f"[WARN] L scan clipped to {L_hi:.6g} "
            f"(L_IR={ff.L_IR():.6g}, L_safe={ff.L_safe():.6g}, L_max={ff.L_max():.6g}; eta>=0 + Omega domain)",
            file=sys.stderr,
        )
    return np.logspace(np.log10(args.L_min), np.log10(L_hi), args.n_points)


def print_summary(ff: FrameworkFormulas, rows: list[dict[str, float]], rg_d: float) -> None:
    print("\n=== Unified Field Framework ===")
    print(f"Parameters: {asdict(ff.p)}")
    print(f"L_max (Eq. 15, mathematical): {ff.L_max():.6g}")
    print(f"L_IR  (eta>=0 physical domain):     {ff.L_IR():.6g}")
    print(f"L_safe (Omega >= 0 diagnostic): {ff.L_safe():.6g}\n")

    print(f"{'L':>12} {'M(L)':>14} {'eta(L)':>12} {'u(L)':>12} {'Omega':>12} {'Lambda_eff':>12}")
    print("-" * 78)
    for r in rows:
        print(
            f"{r['L']:12.6g} {r['M']:14.6g} {r['eta']:12.6g} "
            f"{r.get('u_scale', float('nan')):12.6g} {r['Omega']:12.6g} {r['Lambda_eff']:12.6g}"
        )

    eps = abs(4.0 - rg_d) or 0.01
    print("\n--- RG & critical exponents (v4.1 standard WF) ---")
    print(f"lambda* (Eq. 23)     = {ff.lambda_star(rg_d):.6g}")
    print(f"nu (mean field)      = {ff.nu_mean_field(rg_d, epsilon=eps):.6g}")
    print(f"nu (1-loop, Eq. 24)  = {ff.nu_one_loop(eps):.6g}  [O(N) WF one-loop]")
    print(f"nu (2-loop)          = {ff.nu_two_loop(eps):.6g}  [O(N) WF two-loop]")
    print(f"beta'(lambda*)      = {ff.beta_prime_at_star(rg_d):.6g}")
    print(f"gamma_phi*           = {ff.gamma_phi_star(eps):.6g}")

    print("\n--- Black hole (Eq. 25-26) ---")
    print(f"Lambda_eff(R_s=1)    = {ff.Lambda_eff_bh(1.0):.6g}")
    print(f"Omega_BH(R_s=1)      = {ff.Omega_bh(1.0):.6g}")
    print(f"S_BH(R_s=1)          = {ff.S_bh(1.0):.6g}")
    print(f"dS/dt ratio          = {ff.dS_dt_ratio():.6g}")

    print("\n--- Literature links U1-U8 (first checkpoint) ---")
    r0 = rows[0]
    L0 = r0["L"]
    print(f"U1 g_eff_soft(mu=10,L)  = {ff.g_eff_soft(10.0, L0):.6g}  |  hard = {ff.g_eff_hard(10.0, L0):.6g}")
    print(f"U2 I_M                  = {ff.fisher_mass(L0):.6g}  |  flow = {ff.fisher_flow_proxy(L0):.6g}")
    print(f"U3 clock LHS/RHS        = {ff.clock_bound_lhs(L0):.6g} / {ff.clock_bound_rhs(L0):.6g}")
    print(f"U4 psi_LD               = {ff.psi_LD(L0):.6g}  |  leading = {ff.psi_LD_leading(L0):.6g}")
    print(f"U8 Omega / Omega_nr     = {r0['Omega']:.6g} / {ff.Omega_nonreciprocal(L0):.6g}")

    print("\n--- Reference batch U9–U18 (Kohn/Luttinger/Lloyd/Rashba) ---")
    print(f"U9  M_LK / sigma_corr   = {ff.M_luttinger_kohn(L0):.6g} / {ff.sigma_transport_correction(L0):.6g}")
    print(f"U10 v_TL / K / psi_TL   = {ff.tl_velocity():.6g} / {ff.tl_K_parameter():.6g} / {ff.psi_TL_correction(L0):.6g}")
    print(f"U11 Holevo C upper      = {ff.holevo_capacity_upper(L0):.6g}")
    print(f"U12 Lloyd E*dt bound    = {ff.lloyd_energy_time_bound(L0):.6g}")
    print(f"U13 Rashba split(k=M)   = {ff.rashba_splitting(ff.solve_M(L0)):.6g}")
    print(f"U14 eta_valley(P=0.5)   = {ff.eta_valley(L0, 0.5):.6g}")
    print(f"U15 Omega_moire         = {ff.Omega_moire(L0):.6g}")
    print(f"U16 Wannier k-mesh      = {ff.wannier_k_mesh(L0)}")
    M_ent = ff.solve_M_entropic(L0)
    rel_u17 = abs(M_ent - r0["M"]) / (r0["M"] + 1e-30)
    print(
        f"U17 M / M_entropic      = {r0['M']:.6g} / {M_ent:.6g}  "
        f"(rel diff {rel_u17:.4g}, T={ff.p.T_entropic}; T=0 uses Eq.15, not F_ignorance)"
    )
    lam_c = ff.lambda_star(rg_d)
    lam_o = lam_c / (1.0 + ff.p.kappa_diss) if ff.p.kappa_diss > 0 else lam_c
    print(f"U18 lambda*_closed/open = {lam_c:.6g} / {lam_o:.6g} (kappa={ff.p.kappa_diss})")
    print()


def export_json_csv(
    ff: FrameworkFormulas,
    profile: dict[str, np.ndarray],
    rows: list[dict[str, float]],
    out_dir: Path,
    rg_d: float,
) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)

    n_check = min(50, max(len(profile["L"]) // 4, 1))
    small = slice(0, min(n_check, len(profile["L"])))
    err_small = np.abs(
        profile["M"][small]
        - np.array([ff.M_small_asymptotic(L) for L in profile["L"][small]])
    )
    denom = np.abs(np.array([ff.M_small_asymptotic(L) for L in profile["L"][small]])) + 1e-12
    err_small = err_small / denom

    eps = abs(4.0 - rg_d) or 0.01
    summary = {
        "parameters": {
            **asdict(ff.p),
            "L_max_valid": ff.L_max(),
            "L_IR": ff.L_IR(),
            "L_safe": ff.L_safe(),
            "rg_d": rg_d,
        },
        "theory_notes": {
            "model_version": "v4.1",
            "theorem_1": "M^2 = 1/L^2 + 2*eta (equivalent to (1+2L^2*eta)/L^2)",
            "axioms": "complex convolution + holomorphic kernel + convexity + log closure",
            "physical_domain": "0 < L <= L_IR = 1/m (eta >= 0)",
            "rg_equation": "d lambda / d ln L = u(L) * beta(lambda)",
            "u_scale_formula": "(2*eta-M^2)/(M^2-gamma) = -1/(L^2*(M^2-gamma))",
            "omega_role": "diagnostic only, Eq.18, not in RG",
            "nu_formula": "standard Wilson-Fisher: 0.5 + epsilon/4 + epsilon^2/8",
            "I4_leading_formula": "M^2/(4*pi^2) - (m^2/(4*pi^2))*ln(M/m)",
            "L_IR_definition": "physical IR boundary M=m, eta=0",
            "L_safe_definition": "Omega(L)=0 diagnostic crossing",
            "L_max_definition": "Eq.(15) mathematical existence; M^2->gamma, u diverges",
        },
        "checkpoints": rows,
        "asymptotics": {
            "mean_relative_error_M_small": float(np.mean(err_small)),
            "Omega_at_L_max": float(profile["Omega"][-1]),
        },
        "rg_critical": {
            "lambda_star": ff.lambda_star(rg_d),
            "lambda_star_open": ff.lambda_star(rg_d) / (1.0 + ff.p.kappa_diss)
            if ff.p.kappa_diss > 0
            else ff.lambda_star(rg_d),
            "nu_mean_field": ff.nu_mean_field(rg_d, epsilon=eps),
            "nu_one_loop": ff.nu_one_loop(eps),
            "nu_two_loop": ff.nu_two_loop(eps),
            "beta_prime_star": ff.beta_prime_at_star(rg_d),
            "gamma_phi_star": ff.gamma_phi_star(eps),
        },
        "black_hole": {
            "S_bh_Rs1": ff.S_bh(1.0),
            "dS_dt_ratio": ff.dS_dt_ratio(),
            "Omega_bh_Rs1": ff.Omega_bh(1.0),
        },
    }

    (out_dir / "numerical_results.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    csv_lines = ["L,M,eta,Omega,Lambda_eff,I4_leading"]
    for L in profile["L"]:
        r = ff.evaluate_at_L(float(L))
        csv_lines.append(
            f"{r['L']},{r['M']},{r['eta']},{r['Omega']},{r['Lambda_eff']},{r['I4_leading']}"
        )
    (out_dir / "profile.csv").write_text("\n".join(csv_lines) + "\n", encoding="utf-8")



def export_plots(ff, profile, out_dir: Path, *, rg_d: float, lambda0: float):
    paths = export_numerical_plots(ff, profile, out_dir, rg_d=rg_d, lambda0=lambda0)
    paths.extend(export_literature_comparison_plots(ff, profile, out_dir, rg_d=rg_d, lambda0=lambda0))
    return paths

def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)

    if args.quantum or args.quantum_only:
        from quantum_open_system import main as quantum_main

        q_out = Path(args.output_dir) / "quantum"
        q_argv = [
            "--gamma-B",
            str(max(2.0 * args.gamma, 1e-6)),  # invert γ≈(c_s/2)γ_B with c_s=1
            "--m",
            str(args.m),
            "--output-dir",
            str(q_out),
        ]
        print("[Quantum] launching Caldeira-Leggett / Ohmic open-system layer...")
        rc = quantum_main(q_argv)
        if args.quantum_only:
            return rc

    rg_d = 4.0 - args.rg_epsilon if args.rg_epsilon is not None else args.d

    params = FrameworkParams(
        gamma=args.gamma,
        m=args.m,
        d=args.d,
        alpha_bh=args.alpha_bh,
        T_entropic=args.T_entropic,
        kappa_diss=args.kappa_diss,
    )
    ff = FrameworkFormulas(params)
    out_dir = args.output_dir

    L_grid = build_L_grid(ff, args)
    profile = ff.profile(L_grid)

    checkpoint_L = args.L if args.L else [float(L_grid[0]), float(L_grid[len(L_grid) // 2]), float(L_grid[-1])]
    rows = [ff.evaluate_at_L(L) for L in checkpoint_L]

    print_summary(ff, rows, rg_d)

    if args.summary_only:
        return 0

    if not args.no_export and not args.paper_only:
        export_json_csv(ff, profile, rows, out_dir, rg_d)
        print(f"[JSON] {out_dir / 'numerical_results.json'}")
        print(f"[CSV]  {out_dir / 'profile.csv'}")

    if args.paper_figures or args.paper_only:
        paper_paths = export_paper_figures(
            ff, profile, out_dir, rg_d=rg_d, lambda0=args.lambda0
        )
        print(f"[Paper] {len(paper_paths)} files in {out_dir / 'paper_figures'}/")
        for p in paper_paths:
            print(f"        {p.name}")

    if not args.no_plots and not args.paper_only:
        plot_paths = export_plots(ff, profile, out_dir, rg_d=rg_d, lambda0=args.lambda0)
        print(f"[Plots] {len(plot_paths)} charts in {out_dir / 'plots'}/")
        for p in plot_paths:
            print(f"        {p.name}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
