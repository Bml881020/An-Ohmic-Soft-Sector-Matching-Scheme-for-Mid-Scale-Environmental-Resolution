#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Quantum open-system Ohmic / Caldeira-Leggett layer for mid-scale EFT."""
from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.linalg import expm
from scipy.optimize import brentq


@dataclass(frozen=True)
class QuantumBathParams:
    gamma_B: float = 0.05
    m_ir: float = 1.0
    Lambda_uv: float = 50.0
    c_s: float = 1.0
    T: float = 0.5
    hbar: float = 1.0
    omega0: float = 2.0
    n_bath: int = 64
    mass: float = 1.0


class OhmicSpectralDensity:
    def __init__(self, p: QuantumBathParams):
        self.p = p

    def J(self, omega):
        w = np.asarray(omega, dtype=float)
        mask = (w >= self.p.m_ir) & (w <= self.p.Lambda_uv)
        out = np.zeros_like(w, dtype=float)
        out[mask] = np.pi * self.p.gamma_B * w[mask]  # J = pi * gamma * omega (gamma_B := gamma)
        return out

    def bath_mass_shift(self) -> float:
        p = self.p
        return float(2.0 * p.gamma_B * np.log(p.Lambda_uv / p.m_ir))  # delta M_sp^2 = 2 gamma ln

    def midscale_gamma(self) -> float:
        return float(self.p.gamma_B)  # gamma_B is paper gamma; J = pi*gamma*omega

    def discrete_modes(self):
        p = self.p
        omega = np.linspace(p.m_ir, p.Lambda_uv, p.n_bath)
        d_omega = float(omega[1] - omega[0]) if p.n_bath > 1 else 1.0
        Jw = self.J(omega)
        g2 = (2.0 / np.pi) * Jw * omega * d_omega
        return omega, np.sqrt(np.maximum(g2, 0.0))


class InfluenceKernels:
    def __init__(self, bath: OhmicSpectralDensity):
        self.bath = bath
        self.p = bath.p

    def _w(self, n: int = 2048):
        return np.linspace(self.p.m_ir, self.p.Lambda_uv, n)

    def dissipation_kernel(self, tau):
        w = self._w()
        dw = w[1] - w[0]
        Jw = self.bath.J(w)
        tau = np.asarray(tau, dtype=float)
        out = np.zeros_like(tau)
        for i, t in enumerate(tau):
            out[i] = float(np.sum(Jw * np.sin(w * t)) * dw / np.pi)
        return out

    def noise_kernel(self, tau):
        p = self.p
        w = self._w()
        dw = w[1] - w[0]
        Jw = self.bath.J(w)
        x = p.hbar * w / (2.0 * max(p.T, 1e-12))
        coth = np.cosh(x) / np.sinh(np.maximum(x, 1e-12))
        tau = np.asarray(tau, dtype=float)
        out = np.zeros_like(tau)
        for i, t in enumerate(tau):
            out[i] = float(np.sum(Jw * coth * np.cos(w * t)) * dw / np.pi)
        return out

    def classical_noise_kernel(self, tau):
        p = self.p
        w = self._w()
        dw = w[1] - w[0]
        Jw = self.bath.J(w)
        weight = (2.0 * p.T / np.maximum(w, 1e-12)) * Jw
        tau = np.asarray(tau, dtype=float)
        out = np.zeros_like(tau)
        for i, t in enumerate(tau):
            out[i] = float(np.sum(weight * np.cos(w * t)) * dw / np.pi)
        return out


class QuantumToMidscale:
    """Map Ohmic gamma_B to mid-scale gamma and solve M(L)."""

    def __init__(self, p: QuantumBathParams):
        self.p = p
        self.bath = OhmicSpectralDensity(p)
        self.gamma = self.bath.midscale_gamma()
        self.m = p.m_ir

    def eta(self, M: float) -> float:
        return float(0.5 * self.gamma * np.log((M / self.m) ** 2))

    def solve_M(self, L: float) -> float:
        L_ir = 1.0 / self.m
        if L > L_ir + 1e-12:
            raise ValueError("outside eta>=0 domain")

        def f(M2: float) -> float:
            return L**2 * M2 - 1.0 - self.gamma * L**2 * np.log(M2 / self.m**2)

        lo = self.m**2
        hi = max(1.0 / L**2 + 10.0, lo * 4.0)
        for _ in range(40):
            if f(hi) > 0:
                break
            hi *= 2.0
        return float(np.sqrt(brentq(f, lo, hi)))

    def profile(self, L_values):
        M = np.array([self.solve_M(L) for L in L_values])
        eta = np.array([self.eta(m) for m in M])
        return {
            "L": np.asarray(L_values, float),
            "M": M,
            "eta": eta,
            "gamma": np.full_like(M, self.gamma),
            "delta_m2_bath": np.full_like(M, self.bath.bath_mass_shift()),
        }


class CaldeiraLeggettLinear:
    """Exact linear system+bath covariance evolution."""

    def __init__(self, p: QuantumBathParams):
        self.p = p
        self.bath = OhmicSpectralDensity(p)
        self.omega_k, self.g_k = self.bath.discrete_modes()
        self._build()

    def _build(self):
        p = self.p
        n_b = p.n_bath
        K = np.zeros((1 + n_b, 1 + n_b))
        ct = float(np.sum(self.g_k**2 / np.maximum(self.omega_k**2, 1e-18)))
        K[0, 0] = p.mass * p.omega0**2 + ct
        for i, (wk, gk) in enumerate(zip(self.omega_k, self.g_k)):
            K[i + 1, i + 1] = wk**2
            K[0, i + 1] = gk
            K[i + 1, 0] = gk
        Minv = np.diag([1.0 / p.mass] + [1.0] * n_b)
        dim = 2 * (1 + n_b)
        A = np.zeros((dim, dim))
        A[0 : 1 + n_b, 1 + n_b :] = Minv
        A[1 + n_b :, 0 : 1 + n_b] = -K
        self.A = A
        self.dim = dim
        self.n_b = n_b

    def evolve_covariance(self, t, cov0):
        U = expm(self.A * t)
        return U @ cov0 @ U.T

    def init_cov(self):
        p = self.p
        n_b = self.n_b
        cov = np.zeros((self.dim, self.dim))
        cov[0, 0] = p.hbar / (2.0 * p.mass * p.omega0)
        cov[1 + n_b, 1 + n_b] = p.hbar * p.mass * p.omega0 / 2.0
        for i, wk in enumerate(self.omega_k):
            x = p.hbar * wk / (2.0 * max(p.T, 1e-12))
            coth = float(np.cosh(x) / np.sinh(max(x, 1e-12)))
            cov[i + 1, i + 1] = (p.hbar / (2.0 * wk)) * coth
            cov[1 + n_b + i + 1, 1 + n_b + i + 1] = (p.hbar * wk / 2.0) * coth
        return cov

    def system_position_variance(self, times):
        cov0 = self.init_cov()
        out = np.zeros(len(times))
        for i, t in enumerate(times):
            out[i] = float(self.evolve_covariance(float(t), cov0)[0, 0])
        return out


class LindbladDampedOscillator:
    def __init__(self, p: QuantumBathParams, gamma_L=None):
        self.p = p
        self.gamma_L = float(p.gamma_B if gamma_L is None else gamma_L)
        x = p.hbar * p.omega0 / (2.0 * max(p.T, 1e-12))
        self.n_th = float(1.0 / (np.exp(2.0 * x) - 1.0)) if x < 40 else 0.0

    def drift_diffusion(self):
        p = self.p
        g = self.gamma_L
        A = np.array([[0.0, 1.0 / p.mass], [-p.mass * p.omega0**2, -g]])
        Dpp = g * p.hbar * p.mass * p.omega0 * (2.0 * self.n_th + 1.0)
        return A, np.array([[0.0, 0.0], [0.0, Dpp]])

    def evolve_cov(self, times, cov0=None):
        p = self.p
        A, D = self.drift_diffusion()
        if cov0 is None:
            cov0 = np.diag([p.hbar / (2.0 * p.mass * p.omega0), p.hbar * p.mass * p.omega0 / 2.0])

        def rhs(_t, y):
            C = y.reshape(2, 2)
            return (A @ C + C @ A.T + D).ravel()

        sol = solve_ivp(
            rhs,
            (float(times[0]), float(times[-1])),
            cov0.ravel(),
            t_eval=times,
            method="RK45",
            rtol=1e-7,
            atol=1e-9,
        )
        return sol.y.T.reshape(-1, 2, 2)




class OhmicMicroscopicChecks:
    """Honest microscopic checks for the Ohmic construction.

    1) Re Sigma is linear in Lambda (NOT logarithmic).
    2) Soft-projection Rayleigh quotients obey the epsilon-shell lemma.
    3) Matched soft piece ReΣ_sub(ω*)=(2/π)∫_{max(|ω*|,m)}^Λ J/ν² is the
       mid-scale ansatz, compared against the subtracted PV remainder
       to show they are different objects.
    """

    def __init__(self, eta_omega: float, m_ir: float):
        self.eta = float(eta_omega)
        self.m = float(m_ir)

    def re_sigma_raw(self, omega: float, Lambda: float, n: int = 20000) -> float:
        """Re Sigma = (2 eta/pi) * PV int_m^Lambda nu^2/(nu^2-omega^2) dnu."""
        w = abs(float(omega))
        m = self.m
        Lam = float(Lambda)

        def F(nu: float) -> float:
            if abs(nu - w) < 1e-14:
                return nu
            return nu + 0.5 * w * np.log(abs((nu - w) / (nu + w)))

        # closed PV antiderivative of nu^2/(nu^2-w^2)
        return float((2.0 * self.eta / np.pi) * (F(Lam) - F(m)))

    def re_sigma_linear_piece(self, Lambda: float) -> float:
        return float((2.0 * self.eta / np.pi) * (float(Lambda) - self.m))

    def re_sigma_remainder(self, omega: float, Lambda: float) -> float:
        return self.re_sigma_raw(omega, Lambda) - self.re_sigma_linear_piece(Lambda)

    def re_sigma_sub(self, omega: float, Lambda: float) -> float:
        """Paper ReΣ_sub: (2/π) ∫_{max(|ω|,m)}^Λ J(ν)/ν² dν = (2 η_Ω / π) ln(Λ/max(|ω|,m))."""
        lo = max(abs(float(omega)), self.m)
        Lam = float(Lambda)
        if Lam <= lo:
            return 0.0
        return float((2.0 * self.eta / np.pi) * np.log(Lam / lo))

    def soft_ansatz(self, Lambda: float, omega: float | None = None) -> float:
        """Matching object ReΣ_sub(ω*) with default ω*=m (continuum floor)."""
        w = self.m if omega is None else float(omega)
        return self.re_sigma_sub(w, Lambda)

    def scan_lambda(self, Lambdas: np.ndarray, omega: float | None = None) -> dict:
        Lam = np.asarray(Lambdas, dtype=float)
        w = 0.5 * self.m if omega is None else float(omega)
        raw = np.array([self.re_sigma_raw(w, L) for L in Lam])
        lin = np.array([self.re_sigma_linear_piece(L) for L in Lam])
        rem = raw - lin
        soft = np.array([self.soft_ansatz(L, omega=w) for L in Lam])
        # remainder should saturate (not track soft ansatz)
        rng = np.random.default_rng(0)
        rayleigh = {}
        for e in (0.05, 0.1, 0.2):
            ws = rng.uniform((1.0 - e) * self.m, self.m, size=400)
            rq = (ws / self.m) ** 2
            rayleigh[float(e)] = {
                "min": float(rq.min()),
                "max": float(rq.max()),
                "bound_lo": float((1.0 - e) ** 2),
                "bound_hi": 1.0,
            }
        return {
            "Lambda": Lam,
            "ln_Lambda_over_m": np.log(Lam / self.m),
            "omega": w,
            "ReSigma_raw": raw,
            "ReSigma_linear": lin,
            "ReSigma_remainder": rem,
            "soft_ansatz": soft,
            "projection": rayleigh,
        }



def export_quantum_figures(p: QuantumBathParams, out_dir: Path):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    bath = OhmicSpectralDensity(p)
    ker = InfluenceKernels(bath)
    bridge = QuantumToMidscale(p)

    w = np.linspace(0, p.Lambda_uv * 1.1, 800)
    fig, ax = plt.subplots(figsize=(6.2, 3.8))
    ax.plot(w, bath.J(w), color="#1f4e79", lw=2.0, label=r"$J = \pi\gamma\,\omega$")
    ax.axvline(p.m_ir, color="#c45c26", ls="--", label=r"$m$")
    ax.axvline(p.Lambda_uv, color="#2a9d8f", ls="--", label="Lambda")
    ax.set_xlabel("omega")
    ax.set_ylabel("J(omega)")
    ax.set_title("Ohmic quantum bath")
    ax.legend(frameon=False)
    fig.tight_layout()
    fp = out_dir / "q1_ohmic_spectral_density.png"
    fig.savefig(fp, dpi=160)
    plt.close(fig)
    paths.append(fp)

    tau = np.linspace(0.0, 4.0 / p.m_ir, 400)
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.8))
    axes[0].plot(tau, ker.dissipation_kernel(tau), color="#1f4e79", lw=1.8)
    axes[0].set_title(r"$D(\tau)$")
    axes[0].set_xlabel(r"$\tau$")
    axes[0].set_ylabel(r"$D(\tau)$")
    axes[1].plot(tau, ker.noise_kernel(tau), color="#1f4e79", lw=1.8, label="quantum")
    axes[1].plot(tau, ker.classical_noise_kernel(tau), color="#c45c26", lw=1.6, ls="--", label="classical")
    axes[1].set_title(r"$N(\tau)$")
    axes[1].set_xlabel(r"$\tau$")
    axes[1].set_ylabel(r"$N(\tau)$")
    axes[1].legend(frameon=False)
    fig.suptitle("Feynman--Vernon influence kernels", y=1.02)
    fig.tight_layout()
    fp = out_dir / "q2_influence_kernels.png"
    fig.savefig(fp, dpi=160, bbox_inches="tight")
    plt.close(fig)
    paths.append(fp)

    L_ir = 1.0 / p.m_ir
    L = np.logspace(np.log10(1.0 / p.Lambda_uv), np.log10(L_ir), 200)
    L = L[L <= L_ir]
    prof = bridge.profile(L)
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.8))
    axes[0].plot(prof["L"], prof["M"], lw=2.0, label=r"$M(L)$")
    axes[0].plot(prof["L"], 1.0 / prof["L"], ls="--", label=r"$1/L$")
    axes[0].set_xscale("log")
    axes[0].set_yscale("log")
    axes[0].set_xlabel(r"$L$")
    axes[0].set_ylabel(r"$M(L)$")
    axes[0].legend(frameon=False)
    axes[0].set_title(r"Soft mass from $J=\pi\gamma\omega$")
    axes[1].plot(prof["L"], prof["eta"], color="#c45c26", lw=2.0, label=r"$\eta_{\mathrm{eff}}(L)$")
    axes[1].set_xscale("log")
    axes[1].set_xlabel(r"$L$")
    axes[1].set_ylabel(r"$\eta_{\mathrm{eff}}(L)$")
    axes[1].legend(frameon=False)
    axes[1].set_title(r"Soft-mass parameter")
    fig.suptitle("Ohmic bridge to mid-scale closure", y=1.02)
    fig.tight_layout()
    fp = out_dir / "q3_quantum_midscale_bridge.png"
    fig.savefig(fp, dpi=160, bbox_inches="tight")
    plt.close(fig)
    paths.append(fp)

    times = np.linspace(0.0, 12.0 / p.omega0, 400)
    lind = LindbladDampedOscillator(p)
    q2 = lind.evolve_cov(times)[:, 0, 0]
    q2_cl = p.T / (p.mass * p.omega0**2) if p.T > 0 else p.hbar / (2.0 * p.mass * p.omega0)
    fig, ax = plt.subplots(figsize=(6.5, 3.8))
    ax.plot(times, q2, lw=2.0, label="quantum <q^2>")
    ax.axhline(q2_cl, ls="--", label="classical thermal")
    ax.set_xlabel("t")
    ax.legend(frameon=False)
    ax.set_title("Lindblad damped oscillator")
    fig.tight_layout()
    fp = out_dir / "q4_lindblad_variance.png"
    fig.savefig(fp, dpi=160)
    plt.close(fig)
    paths.append(fp)

    if p.n_bath <= 96:
        cl = CaldeiraLeggettLinear(p)
        t2 = np.linspace(0.0, 6.0 / p.omega0, 120)
        fig, ax = plt.subplots(figsize=(6.5, 3.8))
        ax.plot(t2, cl.system_position_variance(t2), lw=2.0)
        ax.set_xlabel("t")
        ax.set_title("Exact linear Caldeira-Leggett")
        fig.tight_layout()
        fp = out_dir / "q5_caldeira_leggett_exact.png"
        fig.savefig(fp, dpi=160)
        plt.close(fig)
        paths.append(fp)

    # q6: microscopic Ohmic checks (ReSigma linear vs soft ansatz; projection lemma)
    eta_omega = np.pi * p.gamma_B  # m=1: gamma_B = eta_Omega/pi
    micro = OhmicMicroscopicChecks(eta_omega=eta_omega, m_ir=p.m_ir)
    Lam = np.geomspace(max(p.m_ir * 1.5, 2.0), max(p.Lambda_uv, 50.0), 24)
    scan = micro.scan_lambda(Lam)
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.9))
    axes[0].plot(scan["Lambda"], scan["ReSigma_raw"], color="#1f4e79", lw=2.0, label=r"$\operatorname{Re}\Sigma$ (raw)")
    axes[0].plot(scan["Lambda"], scan["ReSigma_linear"], color="#2a9d8f", ls="--", lw=1.8, label=r"linear $(2\eta_\Omega/\pi)(\Lambda-m)$")
    axes[0].plot(scan["Lambda"], scan["ReSigma_remainder"], color="#6c757d", lw=1.6, label="remainder after subtraction")
    axes[0].plot(scan["Lambda"], scan["soft_ansatz"], color="#c45c26", lw=2.0, label=r"soft ansatz $(2\eta_\Omega/\pi)\ln(\Lambda/m)$")
    axes[0].set_xscale("log")
    axes[0].set_xlabel(r"$\Lambda$")
    axes[0].set_ylabel("mass-shift units")
    axes[0].set_title(r"Ohmic $\operatorname{Re}\Sigma$ vs soft logarithm")
    axes[0].legend(frameon=False, fontsize=7)
    eps_keys = sorted(scan["projection"].keys())
    lo = [scan["projection"][e]["min"] for e in eps_keys]
    hi = [scan["projection"][e]["max"] for e in eps_keys]
    blo = [scan["projection"][e]["bound_lo"] for e in eps_keys]
    bhi = [scan["projection"][e]["bound_hi"] for e in eps_keys]
    axes[1].fill_between(eps_keys, blo, bhi, color="#1f4e79", alpha=0.15, label="lemma bounds")
    axes[1].vlines(eps_keys, lo, hi, color="#c45c26", lw=2.0, label="shell Rayleigh span")
    axes[1].plot(eps_keys, lo, "o", color="#c45c26")
    axes[1].plot(eps_keys, hi, "o", color="#c45c26")
    axes[1].set_xlabel(r"shell width $\varepsilon$")
    axes[1].set_ylabel(r"$\|\partial_\tau\phi\|^2/(m^2\|\phi\|^2)$")
    axes[1].set_title(r"Soft-projection lemma")
    axes[1].legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fp = out_dir / "q6_euclidean_soft_log.png"
    fig.savefig(fp, dpi=160)
    plt.close(fig)
    paths.append(fp)

    tab_dir = out_dir.parent if out_dir.name == "plots" else out_dir
    tab_dir = Path(tab_dir)
    tab_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({
        "Lambda": scan["Lambda"],
        "ln_Lambda_over_m": scan["ln_Lambda_over_m"],
        "ReSigma_raw": scan["ReSigma_raw"],
        "ReSigma_linear": scan["ReSigma_linear"],
        "ReSigma_remainder": scan["ReSigma_remainder"],
        "soft_ansatz": scan["soft_ansatz"],
    }).to_csv(tab_dir / "q6_soft_log_scan.csv", index=False)

    return paths


def export_quantum_tables(p: QuantumBathParams, out_dir: Path):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    bath = OhmicSpectralDensity(p)
    bridge = QuantumToMidscale(p)
    paths = []
    meta = {
        "params": asdict(p),
        "delta_m2_bath": bath.bath_mass_shift(),
        "midscale_gamma": bath.midscale_gamma(),
        "L_IR": 1.0 / p.m_ir,
    }
    fp = out_dir / "quantum_meta.json"
    fp.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    paths.append(fp)

    L = np.logspace(np.log10(max(1.0 / p.Lambda_uv, 1e-4)), np.log10(1.0 / p.m_ir), 120)
    fp = out_dir / "quantum_midscale_profile.csv"
    pd.DataFrame(bridge.profile(L)).to_csv(fp, index=False)
    paths.append(fp)

    ker = InfluenceKernels(bath)
    tau = np.linspace(0.0, 3.0 / p.m_ir, 200)
    dfk = pd.DataFrame({
        "tau": tau,
        "D": ker.dissipation_kernel(tau),
        "N_quantum": ker.noise_kernel(tau),
        "N_classical": ker.classical_noise_kernel(tau),
    })
    fp = out_dir / "quantum_influence_kernels.csv"
    dfk.to_csv(fp, index=False)
    paths.append(fp)
    return paths


def print_quantum_summary(p: QuantumBathParams):
    bath = OhmicSpectralDensity(p)
    print()
    print("=== Quantum open-system layer (Caldeira-Leggett / Ohmic) ===")
    print("Parameters:", asdict(p))
    print("delta_m2_bath =", round(bath.bath_mass_shift(), 6))
    print("mid-scale gamma =", round(bath.midscale_gamma(), 6))
    print("L_IR =", round(1.0 / p.m_ir, 6))
    print("Dictionary: gamma_B is paper gamma with J = pi*gamma*omega.")
    print()


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description="Quantum open-system Ohmic bath layer")
    ap.add_argument("--gamma-B", type=float, default=0.05, dest="gamma_B")
    ap.add_argument("--m", type=float, default=1.0, dest="m_ir")
    ap.add_argument("--Lambda", type=float, default=50.0, dest="Lambda_uv")
    ap.add_argument("--c-s", type=float, default=1.0, dest="c_s")
    ap.add_argument("--T", type=float, default=0.5)
    ap.add_argument("--hbar", type=float, default=1.0)
    ap.add_argument("--omega0", type=float, default=2.0)
    ap.add_argument("--n-bath", type=int, default=64)
    ap.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent.parent / "output" / "quantum")
    ap.add_argument("--no-plots", action="store_true")
    return ap.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    p = QuantumBathParams(
        gamma_B=args.gamma_B,
        m_ir=args.m_ir,
        Lambda_uv=args.Lambda_uv,
        c_s=args.c_s,
        T=args.T,
        hbar=args.hbar,
        omega0=args.omega0,
        n_bath=args.n_bath,
    )
    print_quantum_summary(p)
    tabs = export_quantum_tables(p, args.output_dir)
    print("[Tables]", len(tabs), "files in", args.output_dir)
    for f in tabs:
        print(" ", f.name)
    if not args.no_plots:
        figs = export_quantum_figures(p, args.output_dir / "plots")
        print("[Plots]", len(figs), "figures in", args.output_dir / "plots")
        for f in figs:
            print(" ", f.name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
