# -*- coding: utf-8 -*-
"""Dump all numbers quoted in the English manuscript from the current solver."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent
sys.path.insert(0, str(HERE))
from unified_framework import FrameworkFormulas, FrameworkParams


def first_ge(x, y, thr):
    y = np.asarray(y)
    idx = np.where(y >= thr)[0]
    return float(x[idx[0]]) if len(idx) else float("nan")


def C_scan(gamma, N=400):
    ff = FrameworkFormulas(FrameworkParams(gamma=gamma, m=1.0))
    L_ir = ff.L_IR()
    L = np.logspace(-3, np.log10(L_ir), N)
    M_c = np.array([ff.solve_M(float(x)) for x in L])
    M_p = np.array([ff.primary_M(float(x)) for x in L])
    C = -np.log(M_c * L)
    rel = np.abs(M_p - M_c) / np.maximum(np.abs(M_p), 1e-30)
    return float(np.max(np.abs(C))), float(np.max(rel))


def main():
    ff = FrameworkFormulas(FrameworkParams(gamma=0.05, m=1.0))
    L_ir = ff.L_IR()
    L = np.logspace(-3, np.log10(L_ir), 400)
    M = np.array([ff.solve_M(float(x)) for x in L])
    eta = np.array([ff.eta(float(Mi)) for Mi in M])
    u_an = np.array([ff.u_scale(float(x), float(Mi), float(e)) for x, Mi, e in zip(L, M, eta)])
    u_fd = np.array([ff.u_scale_numerical(float(x)) for x in L])
    H = np.abs(L**2 * M**2 - 1.0 - ff.p.gamma * L**2 * np.log((M / ff.p.m) ** 2))
    M2_err = np.abs(M**2 - (1.0 / L**2 + 2.0 * eta))
    n_uv = 80
    Muv = np.array([ff.M_small_asymptotic(float(x)) for x in L[:n_uv]])
    u_rel = np.abs(u_an - u_fd) / np.maximum(np.abs(u_an), 1e-30)

    checkpoints = []
    for Lv in [0.001, 0.01, 0.1, 0.3, 0.5, 0.8, 1.0]:
        Mv = ff.solve_M(Lv)
        ev = ff.eta(Mv)
        uv = ff.u_scale(Lv, Mv, ev)
        checkpoints.append(
            {
                "L": Lv,
                "M": float(Mv),
                "eta": float(ev),
                "two_eta": float(2 * ev),
                "two_eta_L2": float(2 * ev * Lv**2),
                "u": float(uv),
            }
        )

    # sign change of u+1
    sign = np.sign(u_an + 1.0)
    flip = np.where(sign[1:] * sign[:-1] < 0)[0]
    L_flip = float(L[flip[0] + 1]) if len(flip) else float("nan")

    mask05 = L <= 0.05
    u_plus_samples = {str(Lv): float(ff.u_scale(Lv) + 1.0) for Lv in (1e-3, 0.3, 0.7)}

    gamma_rows = []
    for g in [0.02, 0.05, 0.08, 0.10]:
        ffg = FrameworkFormulas(FrameworkParams(gamma=g, m=1.0))
        L_IR, L_max = ffg.L_IR(), ffg.L_max()
        Lg = np.logspace(-3, np.log10(0.999 * min(L_IR, L_max)), 600)
        Mg = np.array([ffg.solve_M(float(x)) for x in Lg])
        etag = np.array([ffg.eta(float(Mi)) for Mi in Mg])
        w = 2 * etag * Lg**2
        ug = np.array([ffg.u_scale(float(x), float(Mi), float(e)) for x, Mi, e in zip(Lg, Mg, etag)])
        gamma_rows.append(
            {
                "gamma": g,
                "L_IR": L_IR,
                "L_max": L_max,
                "L_w01": first_ge(Lg, w, 0.01),
                "L_u05": first_ge(Lg, np.abs(ug + 1), 0.05),
                "w_max": float(np.nanmax(w)),
            }
        )

    C_table = []
    for g in [0.02, 0.05, 0.08, 0.10, 0.12]:
        mxC, mxrel = C_scan(g)
        C_table.append({"gamma": g, "max_abs_C": mxC, "max_rel_M": mxrel})

    q7_path = PAPER / "output" / "quantum" / "discrete_ohmic_matching_test.csv"
    q7 = {}
    if q7_path.exists():
        dfq = pd.read_csv(q7_path)
        q7 = {
            "rel_paper_mean": float(dfq["rel_paper"].mean()),
            "rel_paper_max": float(dfq["rel_paper"].max()),
        }

    fig11_path = PAPER / "figures" / "fig11_scheme_comparison.xlsx"
    schemes = []
    if fig11_path.exists():
        xl = pd.ExcelFile(fig11_path)
        sheet = "schemes" if "schemes" in xl.sheet_names else xl.sheet_names[-1]
        df11 = pd.read_excel(xl, sheet_name=sheet)
        if "kind" in df11.columns:
            schemes = df11.to_dict("records")

    out = {
        "L_IR": float(L_ir),
        "L_max": float(ff.L_max()),
        "u_IR": float(ff.u_scale(1.0)),
        "u_IR_exact": -1.0 / (1.0 - 0.05),
        "max_H": float(np.max(H)),
        "max_M2_err": float(np.max(M2_err)),
        "u_rel_median": float(np.median(u_rel)),
        "u_rel_max": float(np.max(u_rel)),
        "UV_rel_max": float(np.max(np.abs(M[:n_uv] - Muv) / M[:n_uv])),
        "max_abs_u_plus_1_Lle_0.05": float(np.max(np.abs(u_an[mask05] + 1))),
        "L_u_sign_flip": L_flip,
        "u_plus_1_fig6": u_plus_samples,
        "checkpoints": checkpoints,
        "gamma_scan": gamma_rows,
        "C_table": C_table,
        "q7": q7,
        "schemes": schemes,
        "ReSigma_sub_check": {
            "omega_below_m0": ff.ReSigma_sub(0.5, 10.0),
            "omega_at_m0": ff.ReSigma_sub(1.0, 10.0),
            "omega_above": ff.ReSigma_sub(2.0, 10.0),
            "expected_at_m0": 2 * 0.05 * np.log(10.0 / 1.0),
        },
    }
    fp = PAPER / "output" / "paper_numbers.json"
    fp.parent.mkdir(parents=True, exist_ok=True)
    fp.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))
    print("wrote", fp)


if __name__ == "__main__":
    main()
