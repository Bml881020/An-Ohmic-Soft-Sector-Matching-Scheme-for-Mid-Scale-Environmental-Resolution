# -*- coding: utf-8 -*-
"""Independent matching test: Ohmic bath -> Wilson e-fold shells -> mass shift."""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

PAPER = Path(r"C:\Users\ASUS\Desktop\paper_v41")
FIG = PAPER / "figures"
EXCEL = PAPER / "excel"
FIG.mkdir(exist_ok=True)
EXCEL.mkdir(exist_ok=True)

plt.rcParams.update(
    {
        "font.family": "serif",
        "font.size": 11,
        "xtick.direction": "in",
        "ytick.direction": "in",
        "xtick.top": True,
        "ytick.right": True,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "pdf.fonttype": 42,
    }
)

GAMMA = 0.05
M0 = 1.0


def analytic(Lam: np.ndarray) -> np.ndarray:
    return 2.0 * GAMMA * np.log(Lam / M0)


def log_shell_sum(Lam: float, n_shell: int) -> float:
    """Equal-log Wilson shells: ω_n = m0 exp(n Δℓ), each contributes 2γ Δℓ."""
    dl = np.log(Lam / M0) / n_shell
    return float(n_shell * 2.0 * GAMMA * dl)


def linear_riemann(Lam: float, n_bin: int) -> float:
    """Naive linear bins of (2/π) J(ν)/ν² dν = 2γ dν/ν."""
    nu = np.linspace(M0, Lam, n_bin + 1)
    dnu = float(nu[1] - nu[0])
    centers = 0.5 * (nu[:-1] + nu[1:])
    return float(2.0 * GAMMA * np.sum(dnu / centers))


def main() -> None:
    Lambdas = np.geomspace(2.0, 80.0, 24)
    exact = analytic(Lambdas)
    log16 = np.array([log_shell_sum(float(L), 16) for L in Lambdas])
    log256 = np.array([log_shell_sum(float(L), 256) for L in Lambdas])
    lin32 = np.array([linear_riemann(float(L), 32) for L in Lambdas])
    lin512 = np.array([linear_riemann(float(L), 512) for L in Lambdas])

    def pct(a, b):
        return 100.0 * np.abs(a - b) / np.maximum(np.abs(b), 1e-30)

    fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.0))
    ax = axes[0]
    ax.plot(Lambdas, exact, "k-", lw=2.2, label=r"$2\gamma\ln(\Lambda/m_{0})$")
    ax.plot(Lambdas, log16, "o", color="#2a9d8f", ms=5, label=r"log shell $N=16$")
    ax.plot(Lambdas, log256, "s", color="#1d3557", ms=4, label=r"log shell $N=256$")
    ax.plot(Lambdas, lin32, "x", color="#c45c26", ms=5, label=r"linear Riemann $N=32$")
    ax.plot(Lambdas, lin512, "+", color="#e9c46a", ms=7, label=r"linear Riemann $N=512$")
    ax.set_xscale("log")
    ax.set_xlabel(r"$\Lambda$")
    ax.set_ylabel(r"$\delta M^{2}$")
    ax.set_title(r"bath $\to$ Wilson shell $\to$ mass shift")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(True, which="both", ls=":", alpha=0.4)

    ax = axes[1]
    ax.plot(Lambdas, pct(log16, exact), "o-", color="#2a9d8f", lw=1.6, ms=4, label=r"log $N=16$")
    ax.plot(Lambdas, pct(log256, exact), "s-", color="#1d3557", lw=1.6, ms=4, label=r"log $N=256$")
    ax.plot(Lambdas, pct(lin32, exact), "x-", color="#c45c26", lw=1.6, ms=5, label=r"linear $N=32$")
    ax.plot(Lambdas, pct(lin512, exact), "+-", color="#e9c46a", lw=1.6, ms=6, label=r"linear $N=512$")
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel(r"$\Lambda$")
    ax.set_ylabel(r"$100\,|\delta M_N^{2}-2\gamma\ln(\Lambda/m_{0})|/[2\gamma\ln(\Lambda/m_{0})]$  (\%)")
    ax.set_title(r"shell sum vs analytic logarithm")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(True, which="both", ls=":", alpha=0.4)

    fig.subplots_adjust(left=0.08, right=0.98, bottom=0.16, top=0.90, wspace=0.32)
    for ext in (".png", ".pdf"):
        fig.savefig(FIG / f"q7_discrete_matching_test{ext}", bbox_inches="tight", pad_inches=0.18)
    plt.close(fig)

    df = pd.DataFrame(
        {
            "Lambda": Lambdas,
            "analytic": exact,
            "log_N16": log16,
            "log_N256": log256,
            "linear_N32": lin32,
            "linear_N512": lin512,
            "pct_log16": pct(log16, exact),
            "pct_log256": pct(log256, exact),
            "pct_lin32": pct(lin32, exact),
            "pct_lin512": pct(lin512, exact),
        }
    )
    df.to_csv(FIG / "q7_discrete_matching_test.csv", index=False)
    df.to_excel(EXCEL / "q7_discrete_matching_test.xlsx", index=False)
    print("log N=16 max pct", float(df["pct_log16"].max()))
    print("log N=256 max pct", float(df["pct_log256"].max()))
    print("lin N=32 max pct", float(df["pct_lin32"].max()))
    print("lin N=512 max pct", float(df["pct_lin512"].max()))
    print("lin N=512 mean pct", float(df["pct_lin512"].mean()))


if __name__ == "__main__":
    main()
