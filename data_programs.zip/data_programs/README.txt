Ignorance Boundary EFT v41 — 文章数据程序
==========================================
对应文稿：Ignorance_Boundary_EFT_v41_en.tex / Ignorance_Boundary_EFT_v41_en.pdf
图和表仍写到上一级目录的 figures/、excel/、output/，正文引用路径不变。

程序
----
unified_framework.py
  求解器。分辨率质量 M(L)、工作闭包、主定律、u 标度都在这里。

_update_all_figs_data.py
  当前正文用的入口。一次重算文中全部图（PNG+PDF）和对应 Excel。
  图：fig1–fig6、fig8–fig11、q7_discrete_matching_test
  表：paper_tables.xlsx、paper_figures_data.xlsx

quantum_open_system.py
  Ohmic / Caldeira–Leggett 层。输出到 output/quantum/。
  正文已不用 q1–q6 图，这份程序保留浴谱和影响核的计算。

_update_efold_fig.py
  Wilson e-fold 壳与线性 Riemann 和的离散匹配，写出 q7。
  与 _update_all_figs_data.py 写的是同一张 q7；以那份为准。

_dump_paper_numbers.py
  用当前求解器抽出英文稿里引用的数，写到 output/paper_numbers.json。

test_discrete_matching.py
  诊断：工作根 2η 与主定律 2γ ln 的比较。
  不要用它覆盖正文的 q7 图。

怎么跑
------
  python data_programs/_update_all_figs_data.py
  python data_programs/_dump_paper_numbers.py
  python data_programs/quantum_open_system.py

桌面上的 unified_framework.py 仍留给其他脚本导入，本文件夹里是同一份副本。
