# -*- coding: utf-8 -*-
"""Regenerate every manuscript figure (PNG+PDF) and matching Excel/CSV tables."""
from __future__ import annotations

import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
PAPER = HERE.parent
FIG = PAPER / "figures"
EXCEL = PAPER / "excel"
OUT = PAPER / "output" / "paper_figures"
for d in (FIG, EXCEL, OUT):
    d.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(HERE))
from unified_framework import FrameworkFormulas, FrameworkParams

plt.rcParams.update(
    {
        "font.family": "serif",
        "font.size": 11,
        "xtick.direction": "in",
        "ytick.direction": "in",
        "xtick.top": True,
        "ytick.right": True,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "pdf.fonttype": 42,
        "axes.formatter.useoffset": False,
    }
)
C_BLUE, C_ORANGE, C_GREEN, C_GRAY, C_BLACK = "#0072B2", "#E69F00", "#009E73", "#666666", "#222222"
GAMMA, M0, MR = 0.05, 1.0, 1.0


def ticks(ax):
    ax.tick_params(axis="both", which="both", direction="in")


def label_panels(axes, tags=None, style="title"):
    """Add (a), (b), ... . style='title' prefixes the title; 'corner' is for stacked panels."""
    axs = list(np.ravel(np.atleast_1d(axes)))
    if tags is None:
        tags = [f"({chr(ord('a') + i)})" for i in range(len(axs))]
    for ax, tag in zip(axs, tags):
        title = ax.get_title()
        if style == "title" and title:
            ax.set_title(f"{tag}  {title}")
        else:
            ax.text(
                0.02,
                0.95,
                tag,
                transform=ax.transAxes,
                va="top",
                ha="left",
                fontsize=12,
                fontweight="bold",
                zorder=5,
            )


def save_fig(fig, name: str):
    for ax in fig.get_axes():
        ticks(ax)
    for d in (FIG, OUT):
        fig.savefig(d / name, dpi=300, bbox_inches="tight", pad_inches=0.08)
        fig.savefig(d / name.replace(".png", ".pdf"), bbox_inches="tight", pad_inches=0.08)
    plt.close(fig)
    print("fig", name)


def sci(x, n=3):
    """Keep tiny residuals readable in Excel (raw 1e-13 often displays as 0)."""
    return f"{float(x):.{n}e}"


def write_xlsx(name: str, sheets: dict, extra: dict | None = None):
    meta = {
        "gamma": GAMMA,
        "m0": M0,
        "m_R": MR,
        "C_star": 0.0,
        "L_phys": 1.0 / M0,
        "L_ref": 1.0 / MR,
        "note": "Matches Ignorance_Boundary_EFT_v41 after 2026-08-22 refresh",
    }
    if extra:
        meta.update(extra)
    for path in (FIG / name, EXCEL / name, OUT / name):
        with pd.ExcelWriter(path, engine="openpyxl") as w:
            pd.DataFrame([meta]).T.rename(columns={0: "value"}).to_excel(w, sheet_name="parameters")
            for sn, df in sheets.items():
                df.to_excel(w, sheet_name=sn[:31], index=False)
    print("xlsx", name)


def first_ge(Lg, y, thr):
    idx = np.where(np.asarray(y) >= thr)[0]
    return float(Lg[idx[0]]) if len(idx) else np.nan


ff = FrameworkFormulas(FrameworkParams(gamma=GAMMA, m=MR))
L_ref = 1.0 / MR
L = np.logspace(-3, np.log10(0.999 * L_ref), 500)
Mw = np.array([ff.solve_M(float(x)) for x in L])
Mp = np.array([ff.primary_M(float(x), m0=M0) for x in L])
eta_w = np.array([ff.eta(float(Mi)) for Mi in Mw])
eta_p = 0.5 * (Mp**2 - 1.0 / L**2)
Muv = np.array([ff.M_small_asymptotic(float(x)) for x in L])
u_w = np.array([ff.u_scale(float(x)) for x in L])
u_p = -(1.0 + GAMMA * L**2) / (L**2 * Mp**2)
u_fd = np.array([ff.u_scale_numerical(float(x)) for x in L])
H = np.abs(L**2 * Mw**2 - 1.0 - GAMMA * L**2 * np.log((Mw / MR) ** 2))

# ---------------------------------------------------------------------------
# Fig 1 / B.1 real-space kernel
# ---------------------------------------------------------------------------
L0, r = 0.5, np.linspace(0.0, 3.0, 500)
Mw0, et0 = ff.solve_M(L0), ff.eta(ff.solve_M(L0))
K_ord = np.array([ff.K_L_real_modulus(float(ri), L0, 0.0) for ri in r])
K_env = np.array([ff.K_L_real_modulus(float(ri), L0, float(et0)) for ri in r])
fig, axes = plt.subplots(1, 2, figsize=(11.4, 4.4), constrained_layout=True)
axes[0].plot(r, K_ord, "k--", lw=1.8, label=r"ordinary $\eta_{\mathrm{eff}}=0$")
axes[0].plot(r, K_env, color=C_BLUE, lw=2.2, label=rf"$M_{{\mathrm{{w}}}}={Mw0:.3f}$ ($\eta={et0:.4f}$)")
axes[0].set_xlabel(r"$r=\|z\|$")
axes[0].set_ylabel(r"$|K_L|$")
axes[0].set_title(rf"Absolute kernels at $L={L0}$")
axes[0].legend(frameon=False, fontsize=8)
axes[0].grid(True, ls=":", alpha=0.45)
rel_rows = []
for et, col in zip([0.0, 0.05, 0.15, 0.35], ["k", C_BLUE, C_ORANGE, C_GREEN]):
    K = np.array([ff.K_L_real_modulus(float(ri), L0, float(et)) for ri in r])
    ratio = np.divide(K, K_ord, out=np.ones_like(K), where=K_ord > 1e-30)
    axes[1].plot(r, ratio, color=col, lw=2.0, label=rf"$\eta_{{\mathrm{{eff}}}}={et:g}$")
    for ri, kv, rat in zip(r, K, ratio):
        rel_rows.append({"eta": et, "r": float(ri), "K": float(kv), "K_over_K0": float(rat)})
axes[1].set_xlabel(r"$r=\|z\|$")
axes[1].set_ylabel(r"$|K_\eta|/|K_{\eta=0}|$")
axes[1].set_title(r"Relative sharpening at fixed $L$")
axes[1].legend(frameon=False, fontsize=8)
axes[1].grid(True, ls=":", alpha=0.45)
label_panels(axes, style="title")
save_fig(fig, "fig1_realspace_kernel.png")
write_xlsx(
    "fig1_realspace_kernel.xlsx",
    {
        "absolute": pd.DataFrame({"r": r, "K_ordinary": K_ord, "K_working": K_env}),
        "relative": pd.DataFrame(rel_rows),
    },
    {"L_show": L0, "M_w": Mw0, "eta_w": et0},
)

# ---------------------------------------------------------------------------
# Fig 2 / B.6 momentum kernel
# ---------------------------------------------------------------------------
k = np.linspace(0.0, 5.0, 500)
Kh0 = np.array([ff.K_hat_squared(float(kk), 1.0 / L0) for kk in k])
KhM = np.array([ff.K_hat_squared(float(kk), Mw0) for kk in k])
fig, axes = plt.subplots(1, 2, figsize=(11.4, 4.4), constrained_layout=True)
axes[0].plot(k, Kh0, "k--", lw=1.8, label=r"ordinary $M=1/L$")
axes[0].plot(k, KhM, color=C_BLUE, lw=2.2, label=rf"$M_{{\mathrm{{w}}}}={Mw0:.3f}$")
axes[0].set_xlabel(r"$|k|$")
axes[0].set_ylabel(r"$|\hat K_L|^2$")
axes[0].set_title(rf"Momentum kernels at $L={L0}$")
axes[0].legend(frameon=False, fontsize=8)
axes[0].grid(True, ls=":", alpha=0.45)
mom_rel = []
for et, col in zip([0.0, 0.05, 0.15, 0.35], ["k", C_BLUE, C_ORANGE, C_GREEN]):
    Me = math.sqrt((1.0 / L0) ** 2 + 2.0 * et)
    Kh = np.array([ff.K_hat_squared(float(kk), Me) for kk in k])
    axes[1].plot(k, Kh / np.maximum(Kh0, 1e-30), color=col, lw=2.0, label=rf"$\eta_{{\mathrm{{eff}}}}={et:g}$")
    for ki, v in zip(k, Kh):
        mom_rel.append({"eta": et, "k": float(ki), "Khat2": float(v)})
axes[1].set_xlabel(r"$|k|$")
axes[1].set_ylabel(r"ratio to ordinary")
axes[1].set_title(r"Relative momentum sharpening")
axes[1].legend(frameon=False, fontsize=8)
axes[1].grid(True, ls=":", alpha=0.45)
label_panels(axes, style="title")
save_fig(fig, "fig2_momentum_kernel.png")
write_xlsx(
    "fig2_momentum_kernel.xlsx",
    {
        "absolute": pd.DataFrame({"k": k, "Khat2_ordinary": Kh0, "Khat2_working": KhM}),
        "relative": pd.DataFrame(mom_rel),
    },
    {"L_show": L0, "M_w": Mw0},
)

# ---------------------------------------------------------------------------
# Fig 3.1  — soft excess as main panel; Mp vs Mw inset
# ---------------------------------------------------------------------------
fig, axes = plt.subplots(2, 1, figsize=(7.4, 7.4), sharex=True, gridspec_kw={"height_ratios": [2.3, 1.0], "hspace": 0.55})
axes[0].semilogx(L, 2.0 * eta_p * L**2, color=C_BLUE, lw=2.3, label=r"$2\eta_{\mathrm{p}} L^{2}$")
axes[0].semilogx(L, 2.0 * eta_w * L**2, color=C_ORANGE, ls="--", lw=1.8, label=r"$2\eta_{\mathrm{w}} L^{2}$")
axes[0].axhline(0.01, color="k", ls=":", lw=0.9)
axes[0].axvline(L_ref, color=C_GRAY, ls=":", lw=1.0)
axes[0].set_ylabel(r"$2\eta_{\mathrm{eff}} L^{2}$")
axes[0].set_title(r"Relative soft excess (UV $\leftarrow$  $L$  $\rightarrow$ IR)")
axes[0].legend(frameon=False, loc="upper right", fontsize=9)
axes[0].grid(True, which="both", ls=":", alpha=0.45)
axes[0].tick_params(labelbottom=False)
axins = axes[0].inset_axes([0.12, 0.10, 0.40, 0.40])
axins.loglog(L, Mp, color=C_BLACK, lw=1.7, label=r"$M_{\mathrm{p}}$")
axins.loglog(L, Mw, color=C_GREEN, ls="--", lw=1.3, label=r"$M_{\mathrm{w}}$")
axins.set_xlabel(r"$L$", fontsize=7)
axins.set_ylabel(r"$M$", fontsize=7)
axins.tick_params(labelsize=7)
axins.legend(frameon=False, fontsize=6.5, loc="lower left")
axins.grid(True, which="both", ls=":", alpha=0.35)
axes[1].semilogx(L, (Mw - Mp) / Mp, color=C_GREEN, lw=1.8)
axes[1].axhline(0.0, color="k", lw=0.7)
axes[1].axvline(L_ref, color=C_GRAY, ls=":", lw=1.0)
axes[1].set_xlabel(r"Environmental scale $L$  (UV $\leftarrow$  $\cdot$  $\rightarrow$ IR)")
axes[1].set_ylabel(r"$(M_{\mathrm{w}}-M_{\mathrm{p}})/M_{\mathrm{p}}$")
axes[1].set_title("Working vs primary relative mass", pad=8)
axes[1].grid(True, which="both", ls=":", alpha=0.45)
label_panels(axes, style="title")
save_fig(fig, "fig3_M2_decomposition.png")
write_xlsx(
    "fig3_M2_decomposition.xlsx",
    {
        "curves": pd.DataFrame(
            {
                "L": L,
                "inv_L2": 1.0 / L**2,
                "two_eta_p_L2": 2.0 * eta_p * L**2,
                "two_eta_w_L2": 2.0 * eta_w * L**2,
                "M_p": Mp,
                "M_w": Mw,
                "rel_Mw_minus_Mp": (Mw - Mp) / Mp,
            }
        )
    },
)

# ---------------------------------------------------------------------------
# Fig 3.2  — UV error panel only where the expansion is meant to apply
# ---------------------------------------------------------------------------
mask_uv = L <= 0.1
fig, axes = plt.subplots(2, 1, figsize=(7.4, 7.2), sharex=False, gridspec_kw={"height_ratios": [2.2, 1.0], "hspace": 0.62})
axes[0].loglog(L, Mw, color=C_BLUE, lw=2.2, label=r"$M_{\mathrm{w}}$")
axes[0].loglog(L, Muv, color=C_ORANGE, ls="--", lw=1.8, label=r"$M_{\mathrm{UV}}$")
axes[0].plot([L_ref], [MR], marker="*", color=C_ORANGE, ms=12, ls="none", label=r"$L_{\mathrm{ref}}$, $M=m_R$")
axes[0].set_ylabel(r"$M$")
axes[0].set_xlabel(r"$L$")
axes[0].set_title(r"Working root vs UV asymptotic")
axes[0].legend(frameon=False, fontsize=8)
axes[0].grid(True, which="both", ls=":", alpha=0.45)
axes[1].loglog(L[mask_uv], np.abs(Mw[mask_uv] - Muv[mask_uv]) / np.maximum(Mw[mask_uv], 1e-30), color=C_GREEN, lw=1.8)
axes[1].axhline(1e-12, color="k", ls=":", lw=0.8)
axes[1].set_xlabel(r"$L$  (error panel restricted to $L\leq 0.1$)")
axes[1].set_ylabel(r"$|M_{\mathrm{w}}-M_{\mathrm{UV}}|/M_{\mathrm{w}}$")
axes[1].set_title("UV-window relative error", pad=10)
axes[1].grid(True, which="both", ls=":", alpha=0.45)
label_panels(axes, style="title")
save_fig(fig, "fig4_M_vs_L_domain.png")
write_xlsx(
    "fig4_M_vs_L_domain.xlsx",
    {"curves": pd.DataFrame({"L": L, "M_w": Mw, "M_UV": Muv, "rel_err": np.abs(Mw - Muv) / Mw})},
)

# ---------------------------------------------------------------------------
# Fig B.2 u
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7.6, 5.0))
ax.semilogx(L, u_p, color=C_BLUE, lw=2.2, label=r"$u_{\mathrm{p}}$")
ax.semilogx(L, u_w, color=C_ORANGE, ls="--", lw=1.6, label=r"$u_{\mathrm{w}}$")
ax.axhline(-1.0, color=C_GRAY, ls=":", lw=1.2, label=r"UV $u\to-1$")
ax.set_xlabel(r"Environmental scale $L$  (UV $\leftarrow$  $\cdot$  $\rightarrow$ IR)")
ax.set_ylabel(r"$u=d\ln M/d\ln L$")
ax.set_title(r"Scale Jacobians $u_{\mathrm{p}}$ and $u_{\mathrm{w}}$")
ax.legend(frameon=False, fontsize=9)
ax.grid(True, ls=":", alpha=0.45)
save_fig(fig, "fig5_u_scale.png")
write_xlsx("fig5_u_scale.xlsx", {"curves": pd.DataFrame({"L": L, "u_p": u_p, "u_w": u_w, "u_FD": u_fd})})

# ---------------------------------------------------------------------------
# Fig B.3 Delta
# ---------------------------------------------------------------------------
lam_grid = np.linspace(0.0, 12.0, 250)
beta = np.array([ff.beta_phi4(l, 4.0) for l in lam_grid])
fig, ax = plt.subplots(figsize=(7.6, 5.0))
delta_rows = []
for Lv, col, ls in ((1e-3, C_BLUE, "--"), (0.3, C_ORANGE, "-"), (0.7, C_GREEN, "-")):
    uv = ff.u_scale(Lv)
    dlt = (uv + 1.0) * beta
    ax.plot(lam_grid, dlt, color=col, ls=ls, lw=2.0, label=rf"$\Delta$ at $L={Lv:g}$ ($u+1={uv+1:.3g}$)")
    for x, y in zip(lam_grid, dlt):
        delta_rows.append({"L": Lv, "u": uv, "lambda_tilde": float(x), "Delta": float(y), "beta": float(ff.beta_phi4(float(x), 4.0))})
ax.axhline(0.0, color="k", lw=0.8)
ax.set_xlabel(r"$\tilde\lambda$  (dimensionless $\phi^{4}$ coupling)")
ax.set_ylabel(r"$\Delta=(u+1)\beta(\tilde\lambda)$")
ax.set_title(r"$d=4$ one-loop $\beta(\tilde\lambda)=-(3/16\pi^{2})\tilde\lambda^{2}$")
ax.legend(frameon=False, fontsize=8)
ax.grid(True, ls=":", alpha=0.45)
save_fig(fig, "fig6_rg_beta.png")
write_xlsx("fig6_rg_beta.xlsx", {"Delta": pd.DataFrame(delta_rows)})

# ---------------------------------------------------------------------------
# Fig B.5 residuals — absolute errors, no offset notation
# ---------------------------------------------------------------------------
n_uv = 80
fig, axes = plt.subplots(3, 1, figsize=(7.2, 6.6), sharex=False)
axes[0].loglog(L, np.clip(H, 1e-18, None), color=C_BLUE, lw=1.6)
axes[0].set_xlabel(r"$L$")
axes[0].set_ylabel(r"$|H(L,M_{\mathrm{w}})|$")
axes[0].set_title("Closure residual")
axes[0].grid(True, which="both", ls=":", alpha=0.45)
axes[1].loglog(L, np.clip(np.abs(u_w - u_fd), 1e-18, None), color=C_ORANGE, lw=1.6)
axes[1].set_xlabel(r"$L$")
axes[1].set_ylabel(r"$|u_{\mathrm{w}}-u_{\mathrm{FD}}|$")
axes[1].set_title(r"$u_{\mathrm{w}}$ analytic vs central difference")
axes[1].grid(True, which="both", ls=":", alpha=0.45)
axes[2].loglog(L[:n_uv], np.clip(np.abs(Mw[:n_uv] - Muv[:n_uv]) / Mw[:n_uv], 1e-16, None), color=C_GREEN, lw=1.6)
axes[2].set_xlabel(r"$L$")
axes[2].set_ylabel(r"$|M_{\mathrm{w}}-M_{\mathrm{UV}}|/M_{\mathrm{w}}$")
axes[2].set_title("UV asymptotic error (first 80 points)")
axes[2].grid(True, which="both", ls=":", alpha=0.45)
fig.tight_layout(h_pad=1.4)
save_fig(fig, "fig8_numerical_validation.png")
write_xlsx(
    "fig8_numerical_validation.xlsx",
    {
        "residuals": pd.DataFrame(
            {
                "L": L,
                "H": H,
                "u_w": u_w,
                "u_FD": u_fd,
                "u_rel": np.abs(u_w - u_fd) / np.maximum(np.abs(u_w), 1e-30),
                "M_w": Mw,
                "M_UV": Muv,
            }
        )
    },
    {
        "max_abs_H": sci(H.max()),
        "max_identity_viol": sci(np.max(np.abs(Mw**2 - (1.0 / L**2 + 2.0 * eta_w)))),
        "max_u_rel": sci(np.max(np.abs(u_w - u_fd) / np.maximum(np.abs(u_w), 1e-30)), n=6),
        "max_UV_rel_first80": sci(np.max(np.abs(Mw[:n_uv] - Muv[:n_uv]) / Mw[:n_uv])),
        "n_grid": len(L),
        "n_uv": n_uv,
    },
)

# ---------------------------------------------------------------------------
# Fig 3.3 gamma profiles
# ---------------------------------------------------------------------------
overlay = [0.02, 0.05, 0.08, 0.10]
colors_g = {0.02: C_GRAY, 0.05: C_BLUE, 0.08: C_ORANGE, 0.10: C_GREEN}
profiles, prof_rows = {}, []
for g in overlay:
    ffg = FrameworkFormulas(FrameworkParams(gamma=float(g), m=MR))
    Lg = np.logspace(-3, np.log10(0.999), 600)
    Mg = np.array([ffg.solve_M(float(x)) for x in Lg])
    etag = np.array([ffg.eta(float(Mi)) for Mi in Mg])
    profiles[g] = (Lg, Mg, etag)
    for x, M, e in zip(Lg, Mg, etag):
        prof_rows.append({"gamma": g, "L": float(x), "M_w": float(M), "ML_minus_1": float(M * x - 1), "two_eta_L2": float(2 * e * x**2)})

fig, axes = plt.subplots(1, 2, figsize=(12.8, 4.6))
for g, (Lg, Mg, etag) in profiles.items():
    axes[0].semilogx(Lg, Mg * Lg - 1.0, lw=2.0, color=colors_g[g], label=rf"$\gamma={g:g}$")
    axes[1].semilogx(Lg, 2.0 * etag * Lg**2, lw=2.0, color=colors_g[g], label=rf"$\gamma={g:g}$")
axes[0].axhline(0.0, color="k", ls=":", lw=1.0)
axes[0].axvline(1.0, color="k", ls="--", lw=1.0)
axes[0].set_xlabel(r"$L$")
axes[0].set_ylabel(r"$M_{\mathrm{w}}L-1$")
axes[0].set_title(r"Mass shift from $M=1/L$")
axes[0].legend(frameon=False, fontsize=8)
axes[0].grid(True, which="both", ls=":", alpha=0.45)
axes[0].tick_params(right=False)
axes[1].axhline(0.01, color="k", ls=":", lw=1.0, label=r"$2\eta_{\mathrm{eff}} L^{2}=0.01$")
axes[1].axvline(1.0, color="k", ls="--", lw=1.0)
axes[1].set_xlabel(r"$L$")
axes[1].set_ylabel(r"$2\eta_{\mathrm{eff}}^{(w)} L^{2}$", labelpad=12)
axes[1].set_title(r"Soft weight vs $\gamma$")
axes[1].legend(frameon=False, fontsize=8)
axes[1].grid(True, which="both", ls=":", alpha=0.45)
label_panels(axes, style="title")
fig.subplots_adjust(left=0.08, right=0.98, bottom=0.16, top=0.88, wspace=0.48)
save_fig(fig, "fig9_gamma_profiles.png")
write_xlsx("fig9_gamma_profiles.xlsx", {"profiles": pd.DataFrame(prof_rows)})

# ---------------------------------------------------------------------------
# Fig 3.4 scales (no L_u05)
# ---------------------------------------------------------------------------
gammas = np.array([g for g in np.round(np.linspace(0.02, 0.10, 17), 8)])
scale_rows = []
for g in gammas:
    ffg = FrameworkFormulas(FrameworkParams(gamma=float(g), m=MR))
    Lr, Lmax = 1.0 / ffg.p.m, ffg.L_max()
    Lg = np.logspace(-3, np.log10(0.999 * min(Lr, Lmax)), 2000)
    Mg = np.array([ffg.solve_M(float(x)) for x in Lg])
    etag = np.array([ffg.eta(float(Mi)) for Mi in Mg])
    w = 2 * etag * Lg**2
    scale_rows.append({"gamma": float(g), "L_ref": Lr, "L_max": Lmax, "L_w01": first_ge(Lg, w, 0.01)})
df_sc = pd.DataFrame(scale_rows)
fig, ax = plt.subplots(figsize=(7.6, 5.0))
ax.plot(df_sc["gamma"], df_sc["L_ref"], "k--", lw=1.6, label=r"$L_{\mathrm{ref}}=1/m_R$")
ax.plot(df_sc["gamma"], df_sc["L_max"], color=C_GRAY, lw=2.0, label=r"$L_{\max}$")
ax.plot(df_sc["gamma"], df_sc["L_w01"], color=C_BLUE, lw=2.0, marker="o", ms=5.5, label=r"$L_{w01}$")
ax.set_xlabel(r"$\gamma$")
ax.set_ylabel(r"characteristic $L$")
ax.set_title(r"Auxiliary and reference scales vs $\gamma$")
ax.legend(frameon=False, fontsize=9)
ax.grid(True, ls=":", alpha=0.45)
save_fig(fig, "fig10_gamma_scaling.png")
write_xlsx("fig10_gamma_scaling.xlsx", {"scales": df_sc})
write_xlsx("fig9_10_gamma_scan.xlsx", {"scales": df_sc, "profiles": pd.DataFrame(prof_rows)})

# ---------------------------------------------------------------------------
# Fig B.4 scheme comparison
# ---------------------------------------------------------------------------

def solve_scheme(L, gamma, kind, m0=1.0):
    Mloc = 1.0 / L
    for _ in range(80):
        if kind == "m0":
            w = m0
        elif kind == "sqrt":
            w = math.sqrt(m0 * max(Mloc, m0))
        else:
            w = 0.5 * Mloc
        we = max(abs(w), m0)
        arg = 1.0 / (L * we)
        M_new = 1.0 / L if arg <= 1 else float(np.sqrt(1 / L**2 + 2 * gamma * math.log(arg)))
        if abs(M_new - Mloc) < 1e-14:
            return M_new
        Mloc = M_new
    return Mloc


kinds = [("m0", r"$\omega_*=m_0$", C_BLUE), ("sqrt", r"$\omega_*=\sqrt{m_0 M}$", C_ORANGE), ("halfM", r"$\omega_*=M/2$", C_GREEN)]
fig, axes = plt.subplots(1, 2, figsize=(11.4, 4.4), constrained_layout=True)
sch_rows = []
for kind, lab, col in kinds:
    Lg = np.logspace(-3, np.log10(0.999), 400)
    Ms = np.array([solve_scheme(float(x), 0.05, kind) for x in Lg])
    w = 2.0 * 0.5 * (Ms**2 - 1.0 / Lg**2) * Lg**2
    axes[0].semilogx(Lg, w, lw=2.0, color=col, label=lab)
    for x, M, ww in zip(Lg, Ms, w):
        sch_rows.append({"kind": kind, "gamma": 0.05, "L": float(x), "M": float(M), "two_eta_L2": float(ww)})
axes[0].axhline(0.01, color="k", ls=":", lw=1.0)
axes[0].set_xlabel(r"$L$")
axes[0].set_ylabel(r"$2\eta_{\mathrm{eff}} L^{2}$")
axes[0].set_title(r"Soft weight at $\gamma=0.05$")
axes[0].legend(frameon=False, fontsize=8)
axes[0].grid(True, which="both", ls=":", alpha=0.45)

g_list = np.array([0.05, 0.08, 0.10])
lw_rows = []
for kind, lab, col in kinds:
    Lw = []
    for g in g_list:
        Lg = np.logspace(-3, np.log10(0.999), 4000)
        Ms = np.array([solve_scheme(float(x), float(g), kind) for x in Lg])
        w = (Ms**2 - 1.0 / Lg**2) * Lg**2
        val = first_ge(Lg, w, 0.01)
        Lw.append(val)
        lw_rows.append({"kind": kind, "gamma": float(g), "L_w01": val})
    axes[1].plot(g_list, Lw, "-o", color=col, lw=2.0, label=lab)
axes[1].set_xlabel(r"$\gamma$")
axes[1].set_ylabel(r"$L_{w01}$")
axes[1].set_title(r"Auxiliary line $L_{w01}(\gamma)$")
axes[1].legend(frameon=False, fontsize=8)
axes[1].grid(True, ls=":", alpha=0.45)
label_panels(axes, style="title")
save_fig(fig, "fig11_scheme_comparison.png")
write_xlsx("fig11_scheme_comparison.xlsx", {"profiles_g005": pd.DataFrame(sch_rows), "L_w01": pd.DataFrame(lw_rows)})

# ---------------------------------------------------------------------------
# Fig 3.5: independent Wilson e-fold shell sum (not working-root |C|)
# ---------------------------------------------------------------------------
Lambdas = np.geomspace(2.0, 80.0, 24)
analytic = 2.0 * GAMMA * np.log(Lambdas / M0)


def log_shell_sum(Lam: float, n_shell: int) -> float:
    dl = np.log(Lam / M0) / n_shell
    return float(n_shell * 2.0 * GAMMA * dl)


def linear_riemann(Lam: float, n_bin: int) -> float:
    nu = np.linspace(M0, Lam, n_bin + 1)
    dnu = float(nu[1] - nu[0])
    centers = 0.5 * (nu[:-1] + nu[1:])
    return float(2.0 * GAMMA * np.sum(dnu / centers))


log16 = np.array([log_shell_sum(float(x), 16) for x in Lambdas])
log256 = np.array([log_shell_sum(float(x), 256) for x in Lambdas])
lin32 = np.array([linear_riemann(float(x), 32) for x in Lambdas])
lin512 = np.array([linear_riemann(float(x), 512) for x in Lambdas])


def pct_vs(a, b):
    return 100.0 * np.abs(a - b) / np.maximum(np.abs(b), 1e-30)


fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.4))
axes[0].plot(Lambdas, analytic, "k-", lw=2.2, label=r"$2\gamma\ln(\Lambda/m_{0})$")
axes[0].plot(Lambdas, log16, "o", color="#2a9d8f", ms=5, label=r"log shell $N=16$")
axes[0].plot(Lambdas, log256, "s", color="#1d3557", ms=4, label=r"log shell $N=256$")
axes[0].plot(Lambdas, lin32, "x", color="#c45c26", ms=5, label=r"linear Riemann $N=32$")
axes[0].plot(Lambdas, lin512, "+", color="#e9c46a", ms=7, label=r"linear Riemann $N=512$")
axes[0].set_xscale("log")
axes[0].set_xlabel(r"$\Lambda$")
axes[0].set_ylabel(r"$\delta M^{2}$")
axes[0].set_title(r"bath $\to$ Wilson shell $\to$ mass shift")
axes[0].legend(frameon=False, fontsize=8)
axes[0].grid(True, which="both", ls=":", alpha=0.4)
axes[1].plot(Lambdas, pct_vs(log16, analytic), "o-", color="#2a9d8f", lw=1.6, ms=4, label=r"log $N=16$")
axes[1].plot(Lambdas, pct_vs(log256, analytic), "s-", color="#1d3557", lw=1.6, ms=4, label=r"log $N=256$")
axes[1].plot(Lambdas, pct_vs(lin32, analytic), "x-", color="#c45c26", lw=1.6, ms=5, label=r"linear $N=32$")
axes[1].plot(Lambdas, pct_vs(lin512, analytic), "+-", color="#e9c46a", lw=1.6, ms=6, label=r"linear $N=512$")
axes[1].set_xscale("log")
axes[1].set_yscale("log")
axes[1].set_xlabel(r"$\Lambda$")
axes[1].set_ylabel(r"$E_N$ (\%)")
axes[1].set_title(r"percent error vs $2\gamma\ln(\Lambda/m_{0})$")
axes[1].legend(frameon=False, fontsize=8)
axes[1].grid(True, which="both", ls=":", alpha=0.4)
label_panels(axes)
fig.subplots_adjust(left=0.08, right=0.98, bottom=0.16, top=0.90, wspace=0.32)
save_fig(fig, "q7_discrete_matching_test.png")
dfq = pd.DataFrame(
    {
        "Lambda": Lambdas,
        "analytic": analytic,
        "log_N16": log16,
        "log_N256": log256,
        "linear_N32": lin32,
        "linear_N512": lin512,
        "pct_log16": pct_vs(log16, analytic),
        "pct_log256": pct_vs(log256, analytic),
        "pct_lin32": pct_vs(lin32, analytic),
        "pct_lin512": pct_vs(lin512, analytic),
    }
)
pct = dfq["pct_lin32"].to_numpy()
write_xlsx(
    "q7_discrete_matching_test.xlsx",
    {"scan": dfq},
    {
        "max_pct_log16": sci(dfq["pct_log16"].max(), n=2),
        "max_pct_lin32": sci(dfq["pct_lin32"].max(), n=3),
        "max_pct_lin512": sci(dfq["pct_lin512"].max(), n=3),
        "mean_pct_lin512": sci(dfq["pct_lin512"].mean(), n=3),
    },
)
dfq.to_csv(FIG / "q7_discrete_matching_test.csv", index=False)

# ---------------------------------------------------------------------------
# Paper tables
# ---------------------------------------------------------------------------
t22 = []
Lg = np.logspace(-3, 0, 800)
Lg[-1] = 1.0
for g in (0.02, 0.05, 0.08, 0.10, 0.12):
    ffg = FrameworkFormulas(FrameworkParams(gamma=g, m=1.0))
    mxs, dms, dus = [], [], []
    for x in Lg:
        mp = ffg.primary_M(float(x))
        mw = ffg.solve_M(float(x))
        mxs.append(abs(-math.log(mp * x)))
        dms.append(abs(mw - mp) / mp)
        up = -(1 + g * x**2) / (x**2 * mp**2)
        uw = -1.0 / (x**2 * (mw**2 - g))
        dus.append(abs(uw - up))
    t22.append(
        {
            "eps_sm": g,
            "max_abs_C": max(mxs),
            "max_abs_dM_over_Mp": max(dms),
            "max_abs_du": max(dus),
            "du_IR_formula": g**2 / (1.0 - g),
            "used_in_figures": g <= 0.10,
        }
    )

ck = []
for x in (0.001, 0.10, 0.30, 0.50, 0.80, 1.00):
    mp = ff.primary_M(x)
    etp = 0.5 * (mp**2 - 1 / x**2)
    up = -(1 + GAMMA * x**2) / (x**2 * mp**2)
    if x < 1:
        mw = ff.solve_M(x)
        uw = ff.u_scale(x, mw)
    else:
        mw, uw = 1.0, -1.0 / (1.0 - GAMMA)
    ck.append(
        {
            "L": x,
            "M_p": mp,
            "eta_p": etp,
            "two_eta_p_L2": 2 * etp * x**2,
            "u_p": up,
            "M_w": mw,
            "abs_du": abs(uw - up),
        }
    )

mr_rows = []
for mR in (0.8, 1.0, 1.2):
    ffg = FrameworkFormulas(FrameworkParams(gamma=GAMMA, m=mR))
    row = {"m_R": mR, "C_star": -math.log(mR / M0), "L_ref": 1 / mR}
    for x in (0.5, 0.8):
        mp = ffg.primary_M(x, m0=M0)
        mw = ffg.solve_M(x)
        row[f"dM_over_Mp_L{x}"] = abs(mw - mp) / mp
    mr_rows.append(row)

write_xlsx(
    "paper_tables.xlsx",
    {
        "Table2p2": pd.DataFrame(t22),
        "checkpoints": pd.DataFrame(ck),
        "mR_scan": pd.DataFrame(mr_rows),
        "L_w01_working": df_sc,
        "L_w01_schemes": pd.DataFrame(lw_rows),
    },
    {
        "L_max": float(ff.L_max()),
        "max_abs_H": sci(H.max()),
        "max_identity_viol": sci(np.max(np.abs(Mw**2 - (1.0 / L**2 + 2.0 * eta_w)))),
        "max_UV_rel_first80": sci(np.max(np.abs(Mw[:80] - Muv[:80]) / Mw[:80])),
        "q7_max_pct_lin32": sci(dfq["pct_lin32"].max(), n=3),
        "q7_max_pct_lin512": sci(dfq["pct_lin512"].max(), n=3),
    },
)

# bundled workbook
bundle = {
    "fig3": pd.DataFrame({"L": L, "M_p": Mp, "M_w": Mw, "eta_w": eta_w, "eta_p": eta_p, "u_p": u_p, "u_w": u_w}),
    "Table2p2": pd.DataFrame(t22),
    "checkpoints": pd.DataFrame(ck),
}
write_xlsx("paper_figures_data.xlsx", bundle)

readme = """Paper figures and tables — refreshed 2026-08-22
================================================
All manuscript figures exported as PNG + vector PDF.
Excel copies live in figures/, excel/, and output/paper_figures/.

Figures:
  fig1_realspace_kernel
  fig2_momentum_kernel
  fig3_M2_decomposition
  fig4_M_vs_L_domain
  fig5_u_scale
  fig6_rg_beta
  fig8_numerical_validation
  fig9_gamma_profiles
  fig10_gamma_scaling
  fig11_scheme_comparison
  q7_discrete_matching_test

Tables:
  paper_tables.xlsx   (Table 2.2, checkpoints, mR scan, L_w01)
  paper_figures_data.xlsx

Regenerate:
  python paper_v41/data_programs/_update_all_figs_data.py

Deprecated (do not run; they overwrite manuscript files):
  regen_latest_figures.py, _revise_figs_r5.py, _export_all_xlsx.py

Notation: L_phys=1/m0, L_ref=1/m_R. No L_IR, no L_u05.
Unused leftovers (not in the .tex): fig7_nu_application, q1–q6.
"""
(FIG / "README_excel.txt").write_text(readme, encoding="utf-8")
(EXCEL / "README_excel.txt").write_text(readme, encoding="utf-8")
(EXCEL / "README.txt").write_text(readme, encoding="utf-8")
print("L_max", ff.L_max())
print("q7 max pct lin32/lin512", float(dfq["pct_lin32"].max()), float(dfq["pct_lin512"].max()))
print("max|H|", float(H.max()))
print("done")
