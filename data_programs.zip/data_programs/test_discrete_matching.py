# -*- coding: utf-8 -*-
"""Legacy diagnostic: working-root 2η vs primary 2γ ln (the |C| rewrite).

Manuscript Fig 3.5 (q7_discrete_matching_test) is the log-shell vs linear
Riemann discrete-consistency test in _update_all_figs_data.py. This script
must not overwrite that figure.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import brentq


def solve_M(L: float, gamma: float, m: float) -> float:
    def f(M2: float) -> float:
        return L**2 * M2 - 1.0 - gamma * L**2 * np.log(M2 / m**2)

    # UV branch: M >= m
    lo, hi = m**2, max(1.0 / L**2 * 4.0, m**2 * 4.0)
    for _ in range(40):
        if f(lo) * f(hi) <= 0:
            break
        hi *= 2.0
    return float(np.sqrt(brentq(f, lo, hi)))


def re_sigma_closed(omega: float, m: float, Lambda: float, eta: float) -> float:
    """Continuum PV Re Sigma = (2 eta/pi) * [F(Lambda)-F(m)], F=nu+(w/2)ln|(nu-w)/(nu+w)|."""
    w = abs(float(omega))
    if w >= Lambda or abs(w - m) < 1e-14:
        # avoid endpoint singularity; caller should keep m < w < Lambda or w < m
        pass

    def F(nu: float) -> float:
        if abs(nu - w) < 1e-15:
            return nu
        return nu + 0.5 * w * np.log(abs((nu - w) / (nu + w)))

    return float((2.0 * eta / np.pi) * (F(Lambda) - F(m)))


def re_sigma_discrete(omega: float, m: float, Lambda: float, eta: float, n_bath: int = 256) -> float:
    """Discrete Riemann sum for the same PV integral (skip bin containing omega)."""
    w = abs(float(omega))
    nu = np.linspace(m, Lambda, n_bath)
    dnu = float(nu[1] - nu[0])
    # midpoint rule excluding near-pole bins
    centers = 0.5 * (nu[:-1] + nu[1:])
    mask = np.abs(centers - w) > 0.5 * dnu
    centers = centers[mask]
    integrand = centers**2 / (centers**2 - w**2)
    return float((2.0 * eta / np.pi) * np.sum(integrand) * dnu)


def scan(
    gamma_B: float = 0.05,
    m: float = 1.0,
    Lambdas: np.ndarray | None = None,
    n_bath: int = 512,
    omega_star_factor: float = 0.5,
) -> pd.DataFrame:
    # gamma_B is paper gamma: J = pi * gamma * omega
    gamma = float(gamma_B)
    eta = np.pi * gamma  # raw spectral slope for legacy ReSigma helpers
    if Lambdas is None:
        Lambdas = np.geomspace(2.0, 80.0, 20)
    rows = []
    for Lam in Lambdas:
        L = 1.0 / Lam  # Lambda(L) ~ 1/L
        if L > 1.0 / m:
            continue
        M = solve_M(L, gamma, m)
        eta_eff = 0.5 * gamma * np.log((M / m) ** 2)
        two_eta = 2.0 * eta_eff

        # Paper matching: ReΣ_sub(ω*=m0) = 2γ ln(Λ/max(|ω*|, m0))
        paper_sub = 2.0 * gamma * np.log(Lam / max(abs(m), m))

        # Honest continuum ReSigma
        w_star = omega_star_factor * m  # below continuum floor: no pole in [m,Lambda]
        raw = re_sigma_closed(w_star, m, Lam, eta)
        linear = (2.0 * eta / np.pi) * (Lam - m)
        rem = raw - linear
        disc = re_sigma_discrete(w_star, m, Lam, eta, n_bath=n_bath)
        rem_disc = disc - linear

        # Also try near-IR probe just above m (inside continuum), carefully
        w_in = m * 1.05
        if w_in < Lam:
            raw_in = re_sigma_closed(w_in, m, Lam, eta)
            rem_in = raw_in - linear
        else:
            rem_in = np.nan

        rows.append(
            {
                "Lambda": Lam,
                "L": L,
                "M": M,
                "eta_eff": eta_eff,
                "two_eta_eff": two_eta,
                "paper_ReSigma_sub_m": paper_sub,
                "ReSigma_raw_wstar": raw,
                "ReSigma_linear": linear,
                "ReSigma_remainder_wstar": rem,
                "ReSigma_remainder_disc": rem_disc,
                "ReSigma_remainder_win": rem_in,
                "omega_star": w_star,
                "rel_paper": abs(two_eta - paper_sub) / max(abs(paper_sub), 1e-30),
                "rel_rem": abs(two_eta - rem) / max(abs(two_eta), 1e-30),
            }
        )
    return pd.DataFrame(rows)


def main():
    out = Path(r"C:\Users\ASUS\Desktop\paper_v41\figures")
    out.mkdir(parents=True, exist_ok=True)
    tab = Path(r"C:\Users\ASUS\Desktop\paper_v41\output\quantum")
    tab.mkdir(parents=True, exist_ok=True)

    df = scan()
    fp_csv = tab / "discrete_ohmic_matching_test.csv"
    df.to_csv(fp_csv, index=False)

    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.0))
    x = df["Lambda"]

    axes[0].plot(x, df["two_eta_eff"], "o-", color="#c45c26", lw=1.8, ms=5, label=r"$2\eta_{\mathrm{eff}}$ from closure")
    axes[0].plot(x, df["paper_ReSigma_sub_m"], "k--", lw=2.0, label=r"$\delta M_{\mathrm{sp}}^{2}(m_{0})=2\gamma\ln(\Lambda/m_{0})$")
    # discrete per-e-fold Riemann sum 2 gamma sum Delta nu / nu
    gamma = 0.05
    disc_efold = []
    for Lam in x:
        nu = np.linspace(1.0, float(Lam), 512)
        dnu = float(nu[1] - nu[0])
        centers = 0.5 * (nu[:-1] + nu[1:])
        disc_efold.append(2.0 * gamma * np.sum(dnu / centers))
    axes[0].plot(x, disc_efold, ":", color="#2a9d8f", lw=1.8, label=r"discrete $2\gamma\sum\Delta\nu/\nu$")
    axes[0].set_xscale("log")
    axes[0].set_xlabel(r"$\Lambda$ ($L=1/\Lambda$)")
    axes[0].set_ylabel("soft mass shift")
    axes[0].set_title(r"$2\eta_{\mathrm{eff}}$ (working) vs $2\gamma\ln(\Lambda/m_0)$ (primary)")
    axes[0].legend(frameon=False, fontsize=8)

    axes[1].semilogy(x, df["rel_paper"], "o-", color="#c45c26", label=r"$|C|$ rewrite: working vs primary")
    rel_disc = np.abs(df["two_eta_eff"].to_numpy() - np.asarray(disc_efold)) / np.maximum(np.abs(df["paper_ReSigma_sub_m"].to_numpy()), 1e-30)
    axes[1].semilogy(x, rel_disc, "s-", color="#2a9d8f", label=r"working vs discrete e-fold sum")
    axes[1].set_xscale("log")
    axes[1].set_xlabel(r"$\Lambda$")
    axes[1].set_ylabel(r"$|2\eta_{\mathrm{eff}}-2\gamma\ln(\Lambda/m_0)|/|2\gamma\ln(\Lambda/m_0)|$")
    axes[1].set_title(r"$|C|$ residual (not a second matching test)")
    axes[1].legend(frameon=False, fontsize=8)

    fig.subplots_adjust(left=0.10, right=0.98, bottom=0.16, top=0.90, wspace=0.32)
    fp_fig = out / "q7_legacy_working_vs_primary.png"
    fig.savefig(fp_fig, dpi=300, bbox_inches="tight", pad_inches=0.18)
    plt.close(fig)

    print("CSV:", fp_csv)
    print("FIG:", fp_fig)
    print()
    print(df[["Lambda", "two_eta_eff", "paper_ReSigma_sub_m", "ReSigma_remainder_wstar", "rel_paper", "rel_rem"]].to_string(index=False))
    print()
    print("mean rel_paper", float(df["rel_paper"].mean()))
    print("mean rel_rem  ", float(df["rel_rem"].mean()))
    print("max |remainder|", float(np.nanmax(np.abs(df["ReSigma_remainder_wstar"]))))
    print("max paper_sub ", float(df["paper_ReSigma_sub_m"].max()))


if __name__ == "__main__":
    main()
